import xbmc, xbmcgui
from resources.lib import Utils
from resources.lib import YouTube
from resources.lib import TheMovieDB
from resources.lib.WindowManager import wm
from resources.lib.OnClickHandler import OnClickHandler
from resources.lib.library import addon_ID_short

from a4kscrapers_wrapper.tools import log
from inspect import currentframe, getframeinfo

ch = OnClickHandler()

class DialogBaseInfo(object):

	ACTION_PREVIOUS_MENU = [92, 9]
	ACTION_EXIT_SCRIPT = [13, 10]

	def __init__(self, *args, **kwargs):
		super(DialogBaseInfo, self).__init__(*args, **kwargs)
		self.dbid = kwargs.get('dbid')
		self.bouncing = False
		self.data = None
		self.yt_listitems = []
		self.total_items = 0
		self.position = None
		self.info = {}

	def onInit(self, *args, **kwargs):
		super(DialogBaseInfo, self).onInit()
		xbmcgui.Window(10000).setProperty('ImageColor', self.info.get('ImageColor', ''))
		self.window = xbmcgui.Window(self.window_id)
		self.window.setProperty('type', self.type)
		xbmcgui.Window(10000).setProperty('diamondinfo_fanart', self.info.get('fanart', ''))

		#log(Utils.db_con)
		if Utils.trakt_kodi_mode == 'Trakt Only':
			xbmcgui.Window(self.window_id).setProperty('trakt_only', 'true')
		else:
			xbmcgui.Window(self.window_id).clearProperty('trakt_only')
		try: clearlogo = TheMovieDB.get_fanart_clearlogo(tmdb_id=self.info['tmdb_id'],media_type=self.info['media_type'])
		except: clearlogo = ''
		xbmcgui.Window(self.window_id).setProperty('movie.logo', str(clearlogo))
		#xbmcgui.Window(10000).setProperty('movie.tmdbid', str(self.info['tmdb_id']))
		xbmcgui.Window(10000).setProperty(str(addon_ID_short())+'_fanart', self.info.get('fanart', ''))
		xbmc.sleep(500)


	@ch.action('left', '*')
	@ch.action('right', '*')
	@ch.action('up', '*')
	@ch.action('down', '*')
	def save_position(self):
		currently_popping = xbmcgui.Window(10000).getProperty('currently_popping')
		if currently_popping != 'True':
			self.focus_id = self.getFocusId()
			try: self.position = self.getControl(self.focus_id).getSelectedPosition()
			except: self.position = xbmc.getInfoLabel("Container.Position")
			xbmcgui.Window(10000).setProperty('focus_id', str(self.focus_id))
			try:
				int_test = int(self.position)
				xbmcgui.Window(10000).setProperty('position', str(self.position))
			except:
				self.position = 'No Position'
				xbmcgui.Window(10000).setProperty('position', str('No Position'))
			wm.position = self.position
			wm.focus_id = self.focus_id
			xbmcgui.Window(10000).setProperty('focus_id', str(self.focus_id))
			xbmcgui.Window(10000).setProperty('position', str(self.position))
			xbmcgui.Window(10000).setProperty('pop_stack_focus_id', str(self.focus_id))
			xbmcgui.Window(10000).setProperty('pop_stack_position', str(self.position))

	def onAction(self, action):
		#xbmcgui.Window(10000).setProperty('focus_id', str(self.focus_id))
		#xbmcgui.Window(10000).setProperty('position', str(self.position))
		self.save_position()
		wm.wm_curr_windows_props()
		ch.serve_action(action, self.getFocusId(), self)

	def onClick(self, control_id):
		#xbmcgui.Window(10000).setProperty('focus_id', str(self.focus_id))
		#xbmcgui.Window(10000).setProperty('position', str(self.position))
		self.save_position()
		wm.wm_curr_windows_props()
		ch.serve(control_id, self)

	def onFocus(self, control_id):
		self.focus_id = self.getFocusId()
		self.save_position()
		if control_id == 20000:
			if not self.bouncing:
				self.bounce('up')
			self.setFocusId(self.last_focus)
			self.last_focus = control_id
		elif control_id == 20001:
			if not self.bouncing:
				self.bounce('down')
			self.setFocusId(self.last_focus)
			self.last_focus = control_id
		else:
			self.last_focus = control_id

	@Utils.run_async
	def bounce(self, identifier):
		self.bouncing = True
		self.window.setProperty('Bounce.' + identifier, 'true')
		xbmc.sleep(100)
		self.window.clearProperty('Bounce.' + identifier)
		self.bouncing = False

	def fill_lists(self):
		for container_id, listitems in self.listitems:
			self.getControl(container_id).reset()
			self.getControl(container_id).addItems(Utils.create_listitems(listitems,preload_images=0, enable_clearlogo=False, info=self.info))
		xbmc.sleep(100)
		currently_popping = xbmcgui.Window(10000).getProperty('currently_popping')
		if currently_popping == 'True':
			try: wm_curr_window_focus_id = int(wm.curr_window['params']['focus_id'])
			except: wm_curr_window_focus_id = 0
			try: wm_curr_window_position = int(wm.curr_window['params']['position'])
			except: wm_curr_window_position = 0

			if wm_curr_window_focus_id > 0:
				self.focus_id = wm_curr_window_focus_id
			else:
				try: self.focus_id = int(self.focus_id)
				except: self.focus_id = None

			if wm_curr_window_position > 0:
				self.position = wm_curr_window_position
			else:
				try: self.position = int(self.position)
				except: self.position = 0
			pop_stack_position = self.position
			pop_stack_focus_id = self.focus_id

		else:
			self.focus_id = xbmcgui.Window(10000).getProperty('focus_id')
			self.position = xbmcgui.Window(10000).getProperty('position')
			pop_stack_focus_id = xbmcgui.Window(10000).getProperty('pop_stack_focus_id')
			pop_stack_position = xbmcgui.Window(10000).getProperty('pop_stack_position')

		if pop_stack_focus_id != 500:
			self.focus_id = pop_stack_focus_id
			self.position = pop_stack_position
		try: focus_id_int = int(self.focus_id)
		except: focus_id_int = 0
		if str(self.focus_id) != '':
			xbmc.sleep(100)

			try: self.focus_id = int(self.focus_id)
			except: self.focus_id = 500
			if self.focus_id != 500:
				self.setFocusId(int(self.focus_id))
				if str(self.position) != 'No position':
					xbmc.sleep(100)
					try:
						self.getControl(self.focus_id).selectItem(self.position)
						xbmc.sleep(100)
						self.setFocusId(self.focus_id)
					except:
						control = self.getControl(self.focus_id)
						xbmc.sleep(100)
						self.setFocus(control)
				new_focus_id = self.getFocusId()
				try: new_position = self.getControl(self.focus_id).getSelectedPosition()
				except: new_position = xbmc.getInfoLabel("Container.Position")
				try: test_position = int(self.position)
				except: test_position = None

				window_id = xbmcgui.getCurrentWindowId()
				focused_control = window = xbmcgui.Window(window_id).getFocusId()
				diamond_window_number = xbmcgui.Window(10000).getProperty('diamond_window_number')


				if xbmc.getCondVisibility('Control.IsVisible(%s)' % self.focus_id) == False:
					xbmc.executebuiltin('Control.SetFocus(%s,%s)' % (self.focus_id,self.position))
				if xbmc.getCondVisibility('Control.IsVisible(%s)' % self.focus_id) == True:
					if self.focus_id == new_focus_id:
						if test_position:
							if new_position == test_position:
								xbmcgui.Window(10000).clearProperty('currently_popping')
						else:
							xbmcgui.Window(10000).clearProperty('currently_popping')


	@ch.click(1250)
	@ch.click(1350)
	def open_image(self):
		listitems = next((v for (i, v) in self.listitems if i == self.control_id), None)
		index = self.control.getSelectedPosition()
		pos = wm.open_slideshow(listitems=listitems, index=index)
		self.control.selectItem(pos)

	@ch.action('contextmenu', 1250)
	def thumbnail_options(self):
		if not self.info.get('dbid'):
			return None
		selection = xbmcgui.Dialog().select(heading='Artwork', list=['Use as thumbnail'])
		if selection == 0:
			path = self.listitem.getProperty('original')
			media_type = self.window.getProperty('type')
			params = '"art": {"poster": "%s"}' % path
			Utils.get_kodi_json(method='VideoLibrary.Set%sDetails' % media_type, params='{ %s, "%sid":%s }' % (params, media_type.lower(), self.info['dbid']))

	@ch.action('contextmenu', 1350)
	def fanart_options(self):
		if not self.info.get('dbid'):
			return None
		selection = xbmcgui.Dialog().select(heading='Fanart', list=['Use as fanart'])
		if selection == 0:
			path = self.listitem.getProperty('original')
			media_type = self.window.getProperty('type')
			params = '"art": {"fanart": "%s"}' % path
			Utils.get_kodi_json(method='VideoLibrary.Set%sDetails' % media_type, params='{ %s, "%sid":%s }' % (params, media_type.lower(), self.info['dbid']))

	@ch.action('parentdir', '*')
	@ch.action('parentfolder', '*')
	#@ch.action('back', '*')
	def previous_menu(self):
		import sys
		if 'script=false' in str(sys.argv).lower() or 'diamondinfo' in str(sys.argv) or 'extendedinfo' in str(sys.argv) or 'extendedactorinfo' in str(sys.argv) or 'extendedtvinfo' in str(sys.argv) or 'seasoninfo' in str(sys.argv) or 'extendedepisodeinfo' in str(sys.argv):
			window_stack_enable2 = False
			if 'script=true' in str(sys.argv).lower() or 'reopen_window' in str(sys.argv).lower() :
				window_stack_enable2 = True
		else:
			window_stack_enable2 = True

		if Utils.window_stack_enable == 'false' and window_stack_enable2:
			self.close()
			try: del self
			except: pass
			return wm.open_video_list(search_str='', mode='reopen_window')

		onback = self.window.getProperty('%i_onback' % self.control_id)
		if onback:
			xbmc.executebuiltin(onback)
		else:
			#self.close()
			self.close()
			log('wm.pop_stack()',str(str('Line ')+str(getframeinfo(currentframe()).lineno)+'___'+str(getframeinfo(currentframe()).filename)))
			xbmcgui.Window(10000).clearProperty('diamond_window_number')
			wm.pop_stack()

	@ch.action('previousmenu', '*')
	def exit_script(self):
		xbmcgui.Window(10000).clearProperty('currently_popping')
		Utils.db_con.close()
		self.close()
		try: del self
		except: pass

	@Utils.run_async
	def get_youtube_vids(self, search_str):
		try:
			youtube_list = self.getControl(350)
		except:
			return None
		try:
			result = YouTube.search_youtube(search_str, limit=10)
		except:
			return None
		if not self.yt_listitems:
			self.yt_listitems = result.get('listitems', [])
			if 'videos' in self.data:
				vid_ids = [item['key'] for item in self.data['videos']]
				self.yt_listitems = [i for i in self.yt_listitems if i['youtube_id'] not in vid_ids]
		youtube_list.reset()
		youtube_list.addItems(Utils.create_listitems(self.yt_listitems))

	def open_credit_dialog(self, credit_id):
		info = TheMovieDB.get_credit_info(credit_id)
		listitems = []
		if 'seasons' in info['media']:
			listitems += TheMovieDB.handle_tmdb_seasons(info['media']['seasons'])
		if 'episodes' in info['media']:
			listitems += TheMovieDB.handle_tmdb_episodes(info['media']['episodes'])
		if not listitems:
			listitems += [{'label': 'No information available'}]
		listitem, index = wm.open_selectdialog(listitems=listitems)
		if listitem['media_type'] == 'episode':
			wm.open_episode_info(prev_window=self, season=listitems[index]['season'], episode=listitems[index]['episode'], tvshow_id=info['media']['id'])
		elif listitem['media_type'] == 'season':
			wm.open_season_info(prev_window=self, season=listitems[index]['season'], tvshow_id=info['media']['id'])