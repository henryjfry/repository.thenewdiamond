from imdb._logging import imdbpyLogger

logger = imdbpyLogger.getChild('parser')
