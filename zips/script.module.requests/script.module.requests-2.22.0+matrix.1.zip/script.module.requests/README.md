script.module.requests
======================

Python requests library packed for KODI.

See https://github.com/requests/requests
