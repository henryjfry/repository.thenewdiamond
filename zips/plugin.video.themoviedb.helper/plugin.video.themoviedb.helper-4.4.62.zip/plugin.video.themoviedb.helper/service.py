from resources.lib.monitor.service import ServiceMonitor


if __name__ == '__main__':
    ServiceMonitor().run()
