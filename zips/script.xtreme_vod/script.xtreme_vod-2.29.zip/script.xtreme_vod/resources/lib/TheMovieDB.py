import re
import xbmc, xbmcgui, xbmcaddon
from resources.lib import Utils
from resources.lib import local_db
from resources.lib.WindowManager import wm
from resources.lib.library import addon_ID
from resources.lib.library import addon_ID_short
from resources.lib.library import fanart_api_key

import html
from inspect import currentframe, getframeinfo
#xbmc.log(str(str('Line ')+str(getframeinfo(currentframe()).lineno)+'___'+str(getframeinfo(currentframe()).filename))+'===>OPENINFO', level=xbmc.LOGINFO)

ext_key = xbmcaddon.Addon().getSetting('tmdb_api')



if len(ext_key) == 32:
	API_key = ext_key
else:
	API_key = 'edde6b5e41246ab79a2697cd125e1781'

#https://github.com/umbrellaplug/umbrellaplug.github.io/blob/77057a7cf63ab8a628246c986197d3ff88cf0fbf/nexus/plugin.video.umbrella/resources/lib/modules/playcount.py#L8
#https://github.com/umbrellaplug/umbrellaplug.github.io/blob/77057a7cf63ab8a628246c986197d3ff88cf0fbf/nexus/plugin.video.umbrella/resources/lib/context/tmdb.py#L9
#tmdb_api_key = 'edde6b5e41246ab79a2697cd125e1781'
#omdb_api_key = 'd4daa2b'
#tvdb_api_key = '06cff30690f9b9622957044f2159ffae'
#tmdb_API_key = 'bc96b19479c7db6c8ae805744d0bdfe2'

def get_certification_list(media_type):
	response = get_tmdb_data('certification/%s/list?' % media_type, 999999)
	if 'certifications' in response:
		return response['certifications']
	else:
		return []

def merge_with_cert_desc(input_list, media_type):
	cert_list = get_certification_list(media_type)
	for item in input_list:
		if item['iso_3166_1'].upper() not in cert_list:
			continue
		hit = Utils.dictfind(lst=cert_list[item['iso_3166_1'].upper()], key='certification', value=item['certification'])
		if hit:
			item['meaning'] = hit['meaning']
	return input_list

def handle_tmdb_multi_search(results=[]):
	listitems = []
	for item in results:
		if item['media_type'] == 'movie':
			listitem = handle_tmdb_movies([item])[0]
		elif item['media_type'] == 'tv':
			listitem = handle_tmdb_tvshows([item])[0]
		else:
			try: listitem = handle_tmdb_people([item])[0]
			except: continue
		listitems.append(listitem)
	return listitems

def handle_tmdb_movies(results=[], local_first=True, sortkey='year'):
	response = get_tmdb_data('genre/movie/list?language=%s&' % xbmcaddon.Addon().getSetting('LanguageID'), 30)
	id_list = [item['id'] for item in response['genres']]
	label_list = [item['name'] for item in response['genres']]
	movies = []
	for movie in results:
		if 'genre_ids' in movie:
			genre_list = [label_list[id_list.index(genre_id)] for genre_id in movie['genre_ids'] if genre_id in id_list]
			genres = ' / '.join(genre_list)
		else:
			genres = ''
		tmdb_id = str(Utils.fetch(movie, 'id'))
		artwork = get_image_urls(poster=movie.get('poster_path'), fanart=movie.get('backdrop_path'))
		year = Utils.get_year(Utils.fetch(movie, 'release_date'))
		trailer = 'plugin://'+str(addon_ID())+'?info=playtrailer&&id=%s' % str(tmdb_id)
		path = 'plugin://'+str(addon_ID())+'?info='+str(addon_ID_short())+'&&id=%s&year=%s' % (str(tmdb_id), str(year))
		original_title = Utils.fetch(movie, 'original_title')
		original_title2 = ''
		try:
			for i in movie['alternative_titles']['titles']:
				if i['type'] == 'original title' and i['iso_3166_1'] in {'US','UK'}:
					original_title2 = i['title']
			if original_title2 != original_title and original_title2 != '':
				original_title = original_title2
		except KeyError:
			pass
		except TypeError:
			pass
		listitem = {
			'title': Utils.fetch(movie, 'title'),
			'Label': Utils.fetch(movie, 'title'),
			'OriginalTitle': original_title,
			'id': tmdb_id,
			'imdb_id': Utils.fetch(movie, 'imdb_id'),
			'path': path,
			'full_url': Utils.fetch(movie, 'full_url'),
			'stream_id': Utils.fetch(movie, 'stream_id'),
			'media_type': 'movie',
			'mediatype': 'movie',
			'country': Utils.fetch(movie, 'original_language'),
			'plot': Utils.fetch(movie, 'overview'),
			'Trailer': trailer,
			'Popularity': Utils.fetch(movie, 'popularity'),
			'Rating': Utils.fetch(movie, 'vote_average'),
			'credit_id': Utils.fetch(movie, 'credit_id'),
			'character': Utils.fetch(movie, 'character'),
			'job': Utils.fetch(movie, 'job'),
			'department': Utils.fetch(movie, 'department'),
			'Votes': Utils.fetch(movie, 'vote_count'),
			'User_Rating': Utils.fetch(movie, 'rating'),
			'year': year,
			'genre': genres,
			'Premiered': Utils.fetch(movie, 'release_date')
			}
		listitem.update(artwork)
		date = Utils.fetch(movie, 'release_date')
		movies.append(listitem)
	#movies = local_db.merge_with_local_movie_info(movies, local_first, sortkey)
	#Utils.hide_busy()
	return movies

def handle_tmdb_tvshows(results, local_first=True, sortkey='year'):

	tvshows = []
	response = get_tmdb_data('genre/tv/list?language=%s&' % xbmcaddon.Addon().getSetting('LanguageID'), 30)
	id_list = [item['id'] for item in response['genres']]
	label_list = [item['name'] for item in response['genres']]
	for tv in results:
		tmdb_id = Utils.fetch(tv, 'id')
		artwork = get_image_urls(poster=tv.get('poster_path'), fanart=tv.get('backdrop_path'))
		if 'genre_ids' in tv:
			genre_list = [label_list[id_list.index(genre_id)] for genre_id in tv['genre_ids'] if genre_id in id_list]
			genres = ' / '.join(genre_list)
		else:
			genres = ''
		duration = ''
		if 'episode_run_time' in tv:
			if len(tv['episode_run_time']) > 1:
				duration = '%i - %i' % (min(tv['episode_run_time']), max(tv['episode_run_time']))
			elif len(tv['episode_run_time']) == 1:
				duration = '%i' % tv['episode_run_time'][0]

		newtv = {
			'title': Utils.fetch(tv, 'name'),
			'TVShowTitle': Utils.fetch(tv, 'name'),
			'OriginalTitle': Utils.fetch(tv, 'original_name'),
			'duration': duration,
			'id': tmdb_id,
			'imdb_id': Utils.fetch(tv, 'imdb_id'),
			'genre': genres,
			'country': Utils.fetch(tv, 'original_language'),
			'Popularity': Utils.fetch(tv, 'popularity'),
			'credit_id': Utils.fetch(tv, 'credit_id'),
			'Plot': Utils.fetch(tv, 'overview'),
			'Trailer': 'plugin://'+str(addon_ID())+'?info=tvtrailer&&id=%s' % str(tmdb_id),
			'year': Utils.get_year(Utils.fetch(tv, 'first_air_date')),
			'media_type': 'tv',
			'mediatype': 'tvshow',
			'character': Utils.fetch(tv, 'character'),
			'path': 'plugin://'+str(addon_ID())+'?info=extendedtvinfo&&id=%s' % str(tmdb_id),
			'Rating': Utils.fetch(tv, 'vote_average'),
			'User_Rating': str(Utils.fetch(tv, 'rating')),
			'Votes': Utils.fetch(tv, 'vote_count'),
			'TotalEpisodes': Utils.fetch(tv, 'number_of_episodes'),
			'TotalSeasons': Utils.fetch(tv, 'number_of_seasons'),
			'Release_Date': Utils.fetch(tv, 'first_air_date'),
			'status': Utils.fetch(tv, 'status'),
			'Premiered': Utils.fetch(tv, 'first_air_date')
			}
		newtv.update(artwork)
		date = Utils.fetch(tv, 'first_air_date')
		tvshows.append(newtv)
	tvshows = local_db.merge_with_local_tvshow_info(tvshows, local_first, sortkey)
	return tvshows

def handle_tmdb_seasons(results):
	listitems = []
	for season in results:
		season_number = str(Utils.fetch(season, 'season_number'))
		artwork = get_image_urls(poster=season.get('poster_path'))
		title = 'Specials' if season_number == '0' else 'Season %s' % season_number
		listitem = {
			'media_type': 'season',
			'mediatype': 'season',
			'title': title,
			'season': season_number,
			'air_date': Utils.fetch(season, 'air_date'),
			'year': Utils.get_year(Utils.fetch(season, 'air_date')),
			'id': Utils.fetch(season, 'id')
			}
		listitem.update(artwork)
		listitems.append(listitem)
	return listitems

def handle_tmdb_episodes(results):
	listitems = []
	for item in results:
		title = Utils.clean_text(Utils.fetch(item, 'name'))
		if not title:
			title = '%s %s' % ('Episode', Utils.fetch(item, 'episode_number'))
		try:
			artwork = get_image_urls(still=item.get('still_path'))
		except:
			artwork = []
		try: rating = round(float(Utils.fetch(item, 'vote_average')), 1)
		except: rating = 0
		listitem = {
			'media_type': 'episode',
			'mediatype': 'episode',
			'title': title,
			'release_date': Utils.fetch(item, 'air_date'),
			'episode': Utils.fetch(item, 'episode_number'),
			'production_code': Utils.fetch(item, 'production_code'),
			'season': Utils.fetch(item, 'season_number'),
			'Rating': rating,
			'Votes': Utils.fetch(item, 'vote_count'),
			'Plot': Utils.fetch(item, 'overview'),
			'id': Utils.fetch(item, 'id'),
			'Description': Utils.clean_text(Utils.fetch(item, 'overview'))
			}
		listitem.update(artwork)
		date = Utils.fetch(item, 'air_date')
		listitems.append(listitem)
	return listitems

def handle_tmdb_misc(results):
	listitems = []
	for item in results:
		artwork = get_image_urls(poster=item.get('poster_path'))
		listitem = {
			'title': Utils.clean_text(Utils.fetch(item, 'name')),
			'certification': Utils.fetch(item, 'certification') + Utils.fetch(item, 'rating'),
			'item_count': Utils.fetch(item, 'item_count'),
			'release_date': Utils.fetch(item, 'release_date'),
			'path': 'plugin://'+str(addon_ID())+'?info=listmovies&---id=%s' % Utils.fetch(item, 'id'),
			'year': Utils.get_year(Utils.fetch(item, 'release_date')),
			'iso_3166_1': Utils.fetch(item, 'iso_3166_1').lower(),
			'author': Utils.fetch(item, 'author'),
			'content': Utils.clean_text(Utils.fetch(item, 'content')),
			'id': Utils.fetch(item, 'id'),
			'url': Utils.fetch(item, 'url'),
			'Description': Utils.clean_text(Utils.fetch(item, 'description'))
			}
		listitem.update(artwork)
		listitems.append(listitem)
	return listitems

def handle_tmdb_videos(results):
	listitems = []
	for item in results:
		image = 'https://i.ytimg.com/vi/%s/0.jpg' % Utils.fetch(item, 'key')
		listitem = {
			'thumb': image,
			'title': Utils.fetch(item, 'name'),
			'iso_639_1': Utils.fetch(item, 'iso_639_1'),
			'type': Utils.fetch(item, 'type'),
			'key': Utils.fetch(item, 'key'),
			'youtube_id': Utils.fetch(item, 'key'),
			'site': Utils.fetch(item, 'site'),
			'id': Utils.fetch(item, 'id'),
			'size': Utils.fetch(item, 'size')
			}
		listitems.append(listitem)
	return listitems

def handle_tmdb_people(results):
	people = []
	for person in results:
		artwork = get_image_urls(profile=person.get('profile_path'))
		also_known_as = ' / '.join(Utils.fetch(person, 'also_known_as'))
		newperson = {
			'adult': str(Utils.fetch(person, 'adult')),
			'name': person['name'],
			'title': person['name'],
			'also_known_as': also_known_as,
			'alsoknownas': also_known_as,
			'biography': Utils.clean_text(Utils.fetch(person, 'biography')),
			'birthday': Utils.fetch(person, 'birthday'),
			'age': Utils.calculate_age(Utils.fetch(person, 'birthday'), Utils.fetch(person, 'deathday')),
			'character': Utils.fetch(person, 'character'),
			'department': Utils.fetch(person, 'department'),
			'job': Utils.fetch(person, 'job'),
			'media_type': 'person',
			'id': str(person['id']),
			'cast_id': str(Utils.fetch(person, 'cast_id')),
			'credit_id': str(Utils.fetch(person, 'credit_id')),
			'path': 'plugin://'+str(addon_ID())+'?info=extendedactorinfo&&id=%s' % str(person['id']),
			'deathday': Utils.fetch(person, 'deathday'),
			'place_of_birth': Utils.fetch(person, 'place_of_birth'),
			'placeofbirth': Utils.fetch(person, 'place_of_birth'),
			'homepage': Utils.fetch(person, 'homepage')
			}
		newperson.update(artwork)
		people.append(newperson)
	return people

def handle_tmdb_images(results):
	images = []
	for item in results:
		artwork = get_image_urls(poster=item.get('file_path'))
		image = {
			'aspectratio': item['aspect_ratio'],
			'vote_average': Utils.fetch(item, 'vote_average'),
			'iso_639_1': Utils.fetch(item, 'iso_639_1')
			}
		image.update(artwork)
		images.append(image)
	return images

def handle_tmdb_tagged_images(results):
	images = []
	for item in results:
		artwork = get_image_urls(poster=item.get('file_path'))
		image = {
			'aspectratio': item['aspect_ratio'],
			'vote_average': Utils.fetch(item, 'vote_average'),
			'iso_639_1': Utils.fetch(item, 'iso_639_1'),
			'title': Utils.fetch(item['media'], 'title'),
			'mediaposter': 'https://image.tmdb.org/t/p/w500%s' % Utils.fetch(item['media'], 'poster_path')
			}
		image.update(artwork)
		images.append(image)
	return images

def search_company(company_name):
	regex = re.compile('\(.+?\)')
	company_name = regex.sub('', company_name)
	response = get_tmdb_data('search/company?query=%s&' % Utils.url_quote(company_name), 10)
	if response and 'results' in response:
		return response['results']
	else:
		return ''

def get_movie_info(movie_label, year=None, use_dialog=True, item_id=None, notify = True):
	if item_id:
		return single_movie_info(movie_id=item_id, cache_time=7, notify=notify)
	#movies = movie_label.split(' / ')
	if year:
		year_string = '&primary_release_year=' + str(year)
	else:
		year_string = ''
	response = get_tmdb_data('search/movie?query=%s%s&include_adult=%s&' % (Utils.url_quote(movie_label), year_string, xbmcaddon.Addon().getSetting('include_adults')), 30)
	if not response or 'results' not in response:
		return False
	for i in range(len(response['results'])-1, 0, -1):
		if response['results'][i]['title'] != movie_label:
			del response['results'][i]
	if len(response['results']) > 1 and use_dialog:
		listitem, index = wm.open_selectdialog(listitems=handle_tmdb_movies(response['results']))
		if int(index) == -1:
			return False
		elif index >= 0:
			return listitem
	elif response['results']:
		return response['results'][0]
	return False

def get_tvshow_info(tvshow_label, year=None, use_dialog=True, item_id=None):
	if item_id:
		return single_tvshow_info(tvshow_id=item_id, cache_time=7)
	#tvshow = tvshow_label.split(' / ')
	if year:
		year_string = '&first_air_date_year=' + str(year)
	else:
		year_string = ''
	response = get_tmdb_data('search/tv?query=%s%s&include_adult=%s&' % (Utils.url_quote(tvshow_label), year_string, xbmcaddon.Addon().getSetting('include_adults')), 30)
	if not response or 'results' not in response:
		return False
	for i in range(len(response['results'])-1, 0, -1):
		if response['results'][i]['original_name'] != tvshow_label:
			del response['results'][i]
	if len(response['results']) > 1 and use_dialog:
		listitem, index = wm.open_selectdialog(listitems=handle_tmdb_tvshows(response['results']))#
		if int(index) == -1:
			return False
		elif index >= 0:
			return listitem
	elif response['results']:
		return response['results'][0]
	return False

def get_person_info(person_label):
	persons = person_label.split(' / ')
	response = get_tmdb_data('search/person?query=%s&include_adult=%s&' % (Utils.url_quote(persons[0]), xbmcaddon.Addon().getSetting('include_adults')), 30)
	if not response or 'results' not in response:
		return False
	if len(response['results']) > 1:
		listitem, index = wm.open_selectdialog(listitems=handle_tmdb_people(response['results']))
		if index >= 0:
			return response['results'][index]
	elif response['results']:
		return response['results'][0]
	return False

def get_keyword_id(keyword):
	response = get_tmdb_data('search/keyword?query=%s&include_adult=%s&' % (Utils.url_quote(keyword), xbmcaddon.Addon().getSetting('include_adults')), 30)
	if response and 'results' in response and response['results']:
		if len(response['results']) > 1:
			names = [item['name'] for item in response['results']]
			selection = xbmcgui.Dialog().select('Keyword', names)
			if selection > -1:
				return response['results'][selection]
		elif response['results']:
			return response['results'][0]
	else:
		return False

def get_set_id(set_name):
	set_name = set_name.replace('[', '').replace(']', '').replace('Kollektion', 'Collection')
	response = get_tmdb_data('search/collection?query=%s&language=%s&' % (Utils.url_quote(set_name.encode('utf-8')), xbmcaddon.Addon().getSetting('LanguageID')), 14)
	if 'results' in response and response['results']:
		return response['results'][0]['id']
	else:
		return ''

def sort_nested(data, sort_key, asc=True):
	# Helper to recursively find the sort_key in nested structures
	def find_key(obj):
		if isinstance(obj, dict):
			if sort_key in obj:
				return obj[sort_key]
			for value in obj.values():
				result = find_key(value)
				if result is not None:
					return result
		elif isinstance(obj, list):
			for item in obj:
				result = find_key(item)
				if result is not None:
					return result
		return None

	# Determine if input is a list or dict and sort accordingly
	if isinstance(data, dict):
		sorted_items = sorted(data.items(), key=lambda item: find_key(item[1]), reverse=not asc)
		return dict(sorted_items)
	elif isinstance(data, list):
		return sorted(data, key=lambda item: find_key(item), reverse=not asc)
	else:
		raise TypeError("Input must be a list or dictionary")

def get_vod_data(action= None,series_ID = None, cache_days=1, folder='VOD'):
	#url = 'https://api.themoviedb.org/3/%sapi_key=%s' % (url, API_key)
	xtreme_codes_password = Utils.xtreme_codes_password
	xtreme_codes_username = Utils.xtreme_codes_username
	xtreme_codes_server_path = Utils.xtreme_codes_server_path

	actions = ['get_series','get_series_categories','get_series_info','get_vod_categories','get_vod_streams','get_live_categories','get_live_streams',]
	url = '%s/player_api.php?username=%s&password=%s&action=%s' % (xtreme_codes_server_path,xtreme_codes_username,xtreme_codes_password,action)
	if series_ID:
		action = 'get_series_info'
		url = '%s/player_api.php?username=%s&password=%s&action=%s&series=%s' % (xtreme_codes_server_path,xtreme_codes_username,xtreme_codes_password,action,str(series_ID)) 
	#xbmc.log(str(url)+'===>PHIL', level=xbmc.LOGINFO)
	return Utils.get_JSON_response(url, cache_days, folder)


categories = get_vod_data(action= 'get_vod_categories' ,cache_days=1) 

xtreme_sport_categories = xbmcaddon.Addon().getSetting('xtreme_sport_categories')
bad_categories = [i for  i in xtreme_sport_categories.split(',')]
bad_category_ids = [cat['category_id']  for cat in categories  if any(bad.lower() in cat['category_name'].lower() for bad in bad_categories)]


def get_vod_allmovies(category = None, sort_by = None, order_by = None, bad_categories_suppress=True):
	#from resources.lib.TheMovieDB import get_vod_data
	if category == None:
		movies = get_vod_data(action= 'get_vod_streams' ,cache_days=1) 
	else:
		movies = get_vod_data(action= 'get_vod_streams&category_id=%s' % (str(category)) ,cache_days=1) 
	if order_by:
		if order_by == 'desc':
			order_bool = False
		elif order_by == 'asc':
			order_bool = True
	else:
		order_bool = False
	if sort_by == None:
		#movies = sort_nested(movies,'added',False)
		movies = sort_nested(movies,'added',order_bool)
	else:
		movies = sort_nested(movies,sort_by,order_bool)
	search_str = []
	for i in movies:
		if category == None:
			if bad_categories_suppress==True:
				if str(i.get('category_id',0)) in [str(x) for x in bad_category_ids]:
					continue
		if i['name'][:7].lower() == 'movie: ':
			i['name'] = i['name'][7:]
		elif i['name'][:6].lower() == 'movie:':
			i['name'] = i['name'][6:]
		full_url = '%s%s/%s/%s/%s.%s' % (Utils.xtreme_codes_server_path,i['stream_type'],Utils.xtreme_codes_username,Utils.xtreme_codes_password,str(i['stream_id']),str(i['container_extension']))
		search_str.append({'type': 'movie','title':i['name'],'tmdb':i['tmdb'], 'full_url': full_url,'stream_id': i['stream_id'], 'stream_type': i['stream_type'],'stream_icon': i['stream_icon'], 'rating': i['rating'],'category_ids': i['category_ids']})
	return search_str

def get_vod_alltv(category = None, sort_by = None, order_by = None):
	#from resources.lib.TheMovieDB import get_vod_data
	if category == None:
		movies = get_vod_data(action= 'get_series' ,cache_days=1) 
	else:
		movies = get_vod_data(action= 'get_series&category_id=%s' % (str(category)) ,cache_days=1) 

	if order_by:
		if order_by == 'desc':
			order_bool = False
		elif order_by == 'asc':
			order_bool = True
	else:
		order_bool = False
	if sort_by == None:
		#movies = sort_nested(movies,'last_modified',False)
		movies = sort_nested(movies,'last_modified',order_bool)
	else:
		movies = sort_nested(movies,sort_by,order_bool)

	search_str = []
	for i in movies:
		#full_url = '%s%s/%s/%s/%s.%s' % (Utils.xtreme_codes_server_path,i['stream_type'],Utils.xtreme_codes_username,Utils.xtreme_codes_password,str(i['stream_id']),str(i['container_extension']))
		full_url = ''
		search_str.append({'type': 'tv','title':i['name'],'tmdb':i['tmdb'], 'full_url': full_url, 'series_id': i['series_id'],'stream_type': 'tv','stream_icon': i['cover'], 'rating': i['rating'],'category_ids': i['category_ids']})
	return search_str



def get_tmdb_data(url='', cache_days=14, folder='tmdb'):
	url = 'https://api.themoviedb.org/3/%sapi_key=%s' % (url, API_key)
	#xbmc.log(str(url)+'===>PHIL', level=xbmc.LOGINFO)
	return Utils.get_JSON_response(url, cache_days, folder)

def get_fanart_clearlogo(tmdb_id=None, media_type=None):
	fanart_clearlogos = xbmcaddon.Addon().getSetting('fanart_clearlogos')
	if fanart_clearlogos == 'false':
		clearlogo = ''
		return clearlogo
	if media_type !='tv' and media_type != 'movie':
		clearlogo = ''
		return clearlogo
	response = get_fanart_data(tmdb_id=tmdb_id,media_type=media_type)
	if media_type =='tv':
		try:
			for i in response['hdtvlogo']:
				if i['lang'] in ('en','00',''):
					clearlogo = i['url']
					break
		except: 
			try:
				for i in response['clearlogo']:
					if i['lang'] in ('en','00',''):
						clearlogo = i['url']
						break
			except: 
				pass
	if media_type =='movie':
		try:
			for i in response['hdmovielogo']:
				if i['lang'] in ('en','00',''):
					clearlogo = i['url']
					break
		except: 
			try:
				for i in response['clearlogo']:
					if i['lang'] in ('en','00',''):
						clearlogo = i['url']
						break
			except: 
				pass
	return clearlogo

def get_fanart_data(url='', tmdb_id=None, media_type=None, cache_days=14, folder='FanartTV'):
	fanart_api = fanart_api_key()
	import requests,json
	if media_type =='tv':
		tvdb_id = get_tvshow_ids(tmdb_id)
		tvdb_id = tvdb_id['tvdb_id']
		url = 'http://webservice.fanart.tv/v3/tv/'+str(tvdb_id)+'?api_key=' + fanart_api
		#response = requests.get(url).json()
	elif media_type =='tv_tvdb':
		url = 'http://webservice.fanart.tv/v3/tv/'+str(tmdb_id)+'?api_key=' + fanart_api
		#response = requests.get(url).json()
	else:
		url = 'http://webservice.fanart.tv/v3/movies/'+str(tmdb_id)+'?api_key=' + fanart_api
		#response = requests.get(url).json()
	return Utils.get_JSON_response(url, cache_days, folder)



def get_company_data(company_id):
	response = get_tmdb_data('company/%s/movies?' % company_id, 30)
	if response and 'results' in response:
		return handle_tmdb_movies(response['results'])
	else:
		return []

def get_credit_info(credit_id):
	return get_tmdb_data('credit/%s?language=%s&' % (credit_id, xbmcaddon.Addon().getSetting('LanguageID')), 30)

def get_image_urls(poster=None, still=None, fanart=None, profile=None):
	images = {}
	if poster:
		images['poster'] = 'https://image.tmdb.org/t/p/w500' + poster
		images['poster_original'] = 'https://image.tmdb.org/t/p/original' + poster
		images['original'] = 'https://image.tmdb.org/t/p/original' + poster
		images['poster_small'] = 'https://image.tmdb.org/t/p/w342' + poster
		images['thumb'] = 'https://image.tmdb.org/t/p/w342' + poster
	if still:
		images['thumb'] = 'https://image.tmdb.org/t/p/w300' + still
		images['still'] = 'https://image.tmdb.org/t/p/w300' + still
		images['still_original'] = 'https://image.tmdb.org/t/p/original' + still
		images['still_small'] = 'https://image.tmdb.org/t/p/w185' + still
	if fanart:
		images['fanart'] = 'https://image.tmdb.org/t/p/w1280' + fanart
		images['fanart_original'] = 'https://image.tmdb.org/t/p/original' + fanart
		images['original'] = 'https://image.tmdb.org/t/p/original' + fanart
		images['fanart_small'] = 'https://image.tmdb.org/t/p/w780' + fanart
	if profile:
		images['poster'] = 'https://image.tmdb.org/t/p/w500' + profile
		images['poster_original'] = 'https://image.tmdb.org/t/p/original' + profile
		images['poster_small'] = 'https://image.tmdb.org/t/p/w342' + profile
		images['thumb'] = 'https://image.tmdb.org/t/p/w342' + profile
	return images

def get_movie_tmdb_id(imdb_id=None, name=None, dbid=None, Notify=True):
	if dbid and (int(dbid) > 0):
		movie_id = local_db.get_imdb_id_from_db('movie', dbid)
		movie_info = local_db.get_info_from_db('movie', dbid)
		try: year = movie_info['year']
		except: year = ''
		try: original_title = movie_info['originaltitle']
		except: original_title = ''
		if name:
			if original_title != '' and original_title != name:
				name = original_title
		Utils.tools_log('IMDB Id from local DB: %s' % movie_id)
		response = get_tmdb_data('find/%s?external_source=imdb_id&language=%s&' % (movie_id, xbmcaddon.Addon().getSetting('LanguageID')), 30)
		if response['movie_results']:
			return response['movie_results'][0]['id']
		elif name:
			movie = get_movie_info(movie_label=name, year=year)
			if movie and movie.get('id'):
				return movie.get('id')
		else:
			if Notify:
				Utils.notify('Could not find TMDb-id 1')
			return None
	elif imdb_id:
		response = get_tmdb_data('find/%s?external_source=imdb_id&language=%s&' % (imdb_id, xbmcaddon.Addon().getSetting('LanguageID')), 30)
		if 'movie_results' in response:
			if response['movie_results'] != None and len(response['movie_results']) > 0:
				try:
					return response['movie_results'][0]['id']
				except: 
					if name:
						movie = get_movie_info(movie_label=name, year=year)
						if movie and movie.get('id'):
							return movie.get('id')
					else:
						if Notify:
							Utils.notify('Could not find TMDb-id 2')
						return None
			elif name:
				movie = get_movie_info(movie_label=name, year=year)
				if movie and movie.get('id'):
					return movie.get('id')
			else: 
				if Notify:
					Utils.notify('Could not find TMDb-id 3')
				return None
	elif name:
		return search_media(name)
	else:
		if Notify:
			Utils.notify('Could not find TMDb-id 4')
		return None


def get_show_tmdb_id(tvdb_id=None, db=None, imdb_id=None, source=None, Notify=True):
	if tvdb_id:
		id = tvdb_id
		db = 'tvdb_id'
	elif imdb_id:
		id = 'tt%s' % imdb_id
		id = id.replace('tttt','tt')
		db = 'imdb_id'
	response = get_tmdb_data('find/%s?external_source=%s&language=%s&' % (id, db, xbmcaddon.Addon().getSetting('LanguageID')), 30)
	if response:
		return response['tv_results'][0]['id']
	else:
		if Notify:
			Utils.notify('TV Show info not found', time=5000, sound=False)
		return None

def get_trailer(movie_id):
	response = get_tmdb_data('movie/%s?append_to_response=videos,null,%s&language=%s&' % (movie_id, xbmcaddon.Addon().getSetting('LanguageID'), xbmcaddon.Addon().getSetting('LanguageID')), 30)
	if response and 'videos' in response and response['videos']['results']:
		return response['videos']['results'][0]['key']
	Utils.notify('Movie trailer not found', sound=False)
	return ''

def get_tvtrailer(tvshow_id):
	response = get_tmdb_data('tv/%s?append_to_response=videos,null,%s&language=%s&' % (tvshow_id, xbmcaddon.Addon().getSetting('LanguageID'), xbmcaddon.Addon().getSetting('LanguageID')), 30)
	if response and 'videos' in response and response['videos']['results']:
		return response['videos']['results'][0]['key']
	Utils.notify('TV Show trailer not found', sound=False)
	return ''

def play_movie_trailer(id):
	trailer = get_trailer(id)
	xbmc.executebuiltin('PlayMedia(plugin://plugin.video.youtube/play/?video_id=%s,1)' % str(trailer))
	xbmc.executebuiltin('Dialog.Close(busydialog)')

def play_movie_trailer_fullscreen(id):
	trailer = get_trailer(id)
	xbmc.executebuiltin('PlayMedia(plugin://plugin.video.youtube/play/?video_id=%s)' % str(trailer))

def play_tv_trailer(id):
	trailer = get_tvtrailer(id)
	xbmc.executebuiltin('PlayMedia(plugin://plugin.video.youtube/play/?video_id=%s,1)' % str(trailer))
	xbmc.executebuiltin('Dialog.Close(busydialog)')

def play_tv_trailer_fullscreen(id):
	trailer = get_tvtrailer(id)
	xbmc.executebuiltin('PlayMedia(plugin://plugin.video.youtube/play/?video_id=%s)' % str(trailer))

def single_movie_info(movie_id=None, dbid=None, cache_time=14, notify = True):
	if not movie_id:
		return None
	session_str = ''
	response = get_tmdb_data('movie/%s?append_to_response=external_ids,recommendations,rating,alternative_titles&language=%s&%s' % (movie_id, xbmcaddon.Addon().getSetting('LanguageID'), session_str), cache_time)
	#response = get_tmdb_data('movie/%s?append_to_response=alternative_titles,credits,images,keywords,releases,videos,translations,similar,reviews,rating&include_image_language=en,null,%s&language=%s&%s' % (movie_id, xbmcaddon.Addon().getSetting('LanguageID'), xbmcaddon.Addon().getSetting('LanguageID'), session_str), cache_time)
	if not response and notify:
		Utils.notify('Could not get movie information', sound=False)
		return {}
	try: genres = [i['id'] for i in response['genres']]
	except KeyError: genres = []
	results = {
			'media_type': 'movie',
			'mediatype': 'movie',
			'adult': Utils.fetch(response,'adult'),
			'backdrop_path': Utils.fetch(response,'backdrop_path'),
			'genre_ids': genres,
			'id': Utils.fetch(response,'id'),
			'imdb_id': Utils.fetch(Utils.fetch(response, 'external_ids'), 'imdb_id'),
			'original_language': Utils.fetch(response,'original_language'),
			'original_title': Utils.fetch(response,'original_title'),
			'alternative_titles': response.get('alternative_titles',[]),
			'overview': Utils.fetch(response,'overview'),
			'similar': Utils.fetch(response,'recommendations'),
			'Rating': Utils.fetch(response, 'vote_average'),
			'Votes': Utils.fetch(response, 'vote_count'),
			'popularity': Utils.fetch(response,'popularity'),
			'poster_path': Utils.fetch(response,'poster_path'),
			'release_date': Utils.fetch(response,'release_date'),
			'title': Utils.fetch(response,'title'),
			'video': Utils.fetch(response,'video'),
			'vote_average': Utils.fetch(response,'vote_average'),
			'vote_count': Utils.fetch(response,'vote_count')
			}
	return results

def single_tvshow_info(tvshow_id=None, cache_time=7, dbid=None):
	if not tvshow_id:
		return None
	session_str = ''
	response = get_tmdb_data('tv/%s?append_to_response=external_ids,recommendations,rating,alternative_titles&language=%s&%s' % (tvshow_id, xbmcaddon.Addon().getSetting('LanguageID'), session_str), cache_time)
	#response = get_tmdb_data('tv/%s?append_to_response=alternative_titles,content_ratings,credits,external_ids,images,keywords,rating,similar,translations,videos&language=%s&include_image_language=en,null,%s&%s' % (tvshow_id, xbmcaddon.Addon().getSetting('LanguageID'), xbmcaddon.Addon().getSetting('LanguageID'), session_str), cache_time)
	if not response:
		return False
	try: genres = [i['id'] for i in response['genres']]
	except: genres = []
	try: alternative_titles =  [i['title'] for i in response['alternative_titles']['results']]
	except: alternative_titles = []
	if Utils.fetch(response,'original_name') == Utils.fetch(response,'name') and len(alternative_titles) > 0:
		response['original_name'] = alternative_titles[0]
	results = {
		'media_type': 'tv',
		'mediatype': 'tv',
		'backdrop_path': Utils.fetch(response,'backdrop_path'),
		'first_air_date': Utils.fetch(response,'first_air_date'),
		'genre_ids': genres,
		'id': Utils.fetch(response,'id'),
		'imdb_id': Utils.fetch(Utils.fetch(response, 'external_ids'), 'imdb_id'),
		'name': Utils.fetch(response,'name'),
		'title': Utils.fetch(response,'name'),
		'origin_country': Utils.fetch(response,'origin_country'),
		'original_language': Utils.fetch(response,'original_language'),
		'original_name': Utils.fetch(response,'original_name'),
		'alternative_titles': alternative_titles,
		'overview': Utils.fetch(response,'overview'),
		'similar': Utils.fetch(response,'recommendations'),
		'Rating': Utils.fetch(response, 'vote_average'),
		'Votes': Utils.fetch(response, 'vote_count'),
		'popularity': Utils.fetch(response,'popularity'),
		'poster_path': Utils.fetch(response,'poster_path'),
		'status': Utils.fetch(response,'status'),
		'vote_average': Utils.fetch(response,'vote_average'),
		'vote_count': Utils.fetch(response,'vote_count')
		}
	return results

def extended_movie_info(movie_id=None, dbid=None, cache_time=14, notify=True):
	if not movie_id:
		return None
	session_str = ''
	#response = get_tmdb_data('movie/%s?append_to_response=alternative_titles,credits,images,keywords,releases,videos,translations,recommendations,reviews,rating&include_image_language=en,null,%s&language=%s&%s' % (movie_id, xbmcaddon.Addon().getSetting('LanguageID'), xbmcaddon.Addon().getSetting('LanguageID'), session_str), cache_time)
	response = get_tmdb_data('movie/%s?append_to_response=alternative_titles,credits,images,keywords,releases,videos,recommendations,reviews,rating&include_image_language=en,null,%s&language=%s&%s' % (movie_id, xbmcaddon.Addon().getSetting('LanguageID'), xbmcaddon.Addon().getSetting('LanguageID'), session_str), cache_time)
	if not response and notify:
		Utils.notify('Could not get movie information', sound=False)
		return {}
	mpaa = ''
	set_name = ''
	set_id = ''
	genres = [i['name'] for i in response['genres']]
	Studio = [i['name'] for i in response['production_companies']]
	authors = [i['name'] for i in response['credits']['crew'] if i['department'] == 'Writing']
	directors = [i['name'] for i in response['credits']['crew'] if i['department'] == 'Directing']
	us_cert = Utils.dictfind(response['releases']['countries'], 'iso_3166_1', 'US')
	if us_cert:
		mpaa = us_cert['certification']
	elif response['releases']['countries']:
		mpaa = response['releases']['countries'][0]['certification']
	movie_set = Utils.fetch(response, 'belongs_to_collection')
	if movie_set:
		set_name = Utils.fetch(movie_set, 'name')
		set_id = Utils.fetch(movie_set, 'id')
	artwork = get_image_urls(poster=response.get('poster_path'), fanart=response.get('backdrop_path'))
	movie = {
		'media_type': 'movie',
		'mediatype': 'movie',
		'title': Utils.fetch(response, 'title'),
		'Label': Utils.fetch(response, 'title'),
		'Tagline': Utils.fetch(response, 'tagline'),
		'duration': Utils.fetch(response, 'runtime'),
		'duration(h)': Utils.format_time(Utils.fetch(response, 'runtime'), 'h'),
		'duration(m)': Utils.format_time(Utils.fetch(response, 'runtime'), 'm'),
		'duration(hm)': Utils.format_time(Utils.fetch(response, 'runtime')),
		'mpaa': mpaa,
		'Director': ' / '.join(directors),
		'writer': ' / '.join(authors),
		'Budget': Utils.millify(Utils.fetch(response, 'budget')),
		'Revenue': Utils.millify(Utils.fetch(response, 'revenue')),
		'Homepage': Utils.fetch(response, 'homepage'),
		'Set': set_name, 'SetId': set_id,
		'id': Utils.fetch(response, 'id'),
		'tmdb_id': Utils.fetch(response, 'id'),
		'imdb_id': Utils.fetch(response, 'imdb_id'),
		'Plot': Utils.clean_text(Utils.fetch(response, 'overview')),
		'OriginalTitle': Utils.fetch(response, 'original_title'),
		'Country': Utils.fetch(response, 'original_language'),
		'genre': ' / '.join(genres),
		'Rating': Utils.fetch(response, 'vote_average'),
		'Votes': Utils.fetch(response, 'vote_count'),
		'Adult': str(Utils.fetch(response, 'adult')),
		'Popularity': Utils.fetch(response, 'popularity'),
		'Status': translate_status(Utils.fetch(response, 'status')),
		'release_date': Utils.fetch(response, 'release_date'),
		'Premiered': Utils.fetch(response, 'release_date'),
		'Studio': ' / '.join(Studio),
		'year': Utils.get_year(Utils.fetch(response, 'release_date')),
		'path': 'plugin://'+str(addon_ID())+'?info='+str(addon_ID_short())+'&&id=%s' % str(movie_id),
		'trailer': 'plugin://'+str(addon_ID())+'?info=playtrailer&&id=%s' % str(movie_id)
		}
	movie.update(artwork)
	videos = handle_tmdb_videos(response['videos']['results']) if 'videos' in response else []
	if dbid:
		local_item = local_db.get_movie_from_db(dbid)
		movie.update(local_item)
	else:
		movie = local_db.merge_with_local_movie_info([movie])[0]
	movie['Rating'] = Utils.fetch(response, 'vote_average')
	pop_list = []
	for idx, i in enumerate(response['recommendations']['results']):
		if int(i.get('vote_count',0)) < 250:
			pop_list.append(idx)
	for i in reversed(pop_list):
		response['recommendations']['results'].pop(i)

	listitems = {
		'actors': handle_tmdb_people(response['credits']['cast']),
		'similar': handle_tmdb_movies(response['recommendations']['results']),
		'studios': handle_tmdb_misc(response['production_companies']),
		'releases': handle_tmdb_misc(response['releases']['countries']),
		'crew': handle_tmdb_people(response['credits']['crew']),
		'genres': handle_tmdb_misc(response['genres']),
		'keywords': handle_tmdb_misc(response['keywords']['keywords']),
		'reviews': handle_tmdb_misc(response['reviews']['results']),
		'videos': videos,
		'images': handle_tmdb_images(response['images']['posters']),
		'backdrops': handle_tmdb_images(response['images']['backdrops'])
		}
	return (movie, listitems)

def extended_tvshow_info(tvshow_id=None, cache_time=7, dbid=None):
	if not tvshow_id:
		return None
	session_str = ''
	#response = get_tmdb_data('tv/%s?append_to_response=alternative_titles,content_ratings,credits,external_ids,images,keywords,rating,recommendations,translations,videos&language=%s&include_image_language=en,null,%s&%s' % (tvshow_id, xbmcaddon.Addon().getSetting('LanguageID'), xbmcaddon.Addon().getSetting('LanguageID'), session_str), cache_time)
	response = get_tmdb_data('tv/%s?append_to_response=alternative_titles,content_ratings,credits,external_ids,images,keywords,rating,recommendations,videos&language=%s&include_image_language=en,null,%s&%s' % (tvshow_id, xbmcaddon.Addon().getSetting('LanguageID'), xbmcaddon.Addon().getSetting('LanguageID'), session_str), cache_time)
	if not response:
		return False
	videos = handle_tmdb_videos(response['videos']['results']) if 'videos' in response else []
	tmdb_id = Utils.fetch(response, 'id')
	external_ids = Utils.fetch(response, 'external_ids')
	if external_ids:
		imdb_id = Utils.fetch(external_ids, 'imdb_id')
		freebase_id = Utils.fetch(external_ids, 'freebase_id')
		tvdb_id = Utils.fetch(external_ids, 'tvdb_id')
		tvrage_id = Utils.fetch(external_ids, 'tvrage_id')
	artwork = get_image_urls(poster=response.get('poster_path'), fanart=response.get('backdrop_path'))
	if len(response.get('episode_run_time', -1)) > 1:
		duration = '%i - %i' % (min(response['episode_run_time']), max(response['episode_run_time']))
	elif len(response.get('episode_run_time', -1)) == 1:
		duration = '%i' % response['episode_run_time'][0]
	else:
		duration = ''
	us_cert = Utils.dictfind(response['content_ratings']['results'], 'iso_3166_1', 'US')
	if us_cert:
		mpaa = us_cert['rating']
	elif response['content_ratings']['results']:
		mpaa = response['content_ratings']['results'][0]['rating']
	else:
		mpaa = ''
	genres = [item['name'] for item in response['genres']]
	tvshow = {
		'title': Utils.fetch(response, 'name'),
		'TVShowTitle': Utils.fetch(response, 'name'),
		'OriginalTitle': Utils.fetch(response, 'original_name'),
		'duration': duration,
		'duration(h)': Utils.format_time(duration, 'h'),
		'duration(m)': Utils.format_time(duration, 'm'),
		'id': tmdb_id,
		'tmdb_id': tmdb_id,
		'imdb_id': imdb_id,
		'freebase_id': freebase_id,
		'tvdb_id': tvdb_id,
		'tvrage_id': tvrage_id,
		'mpaa': mpaa,
		'genre': ' / '.join(genres),
		'credit_id': Utils.fetch(response, 'credit_id'),
		'Plot': Utils.clean_text(Utils.fetch(response, 'overview')),
		'year': Utils.get_year(Utils.fetch(response, 'first_air_date')),
		'media_type': 'tv',
		'mediatype': 'tvshow',
		'Popularity': Utils.fetch(response, 'popularity'),
		'Rating': Utils.fetch(response, 'vote_average'),
		'country': Utils.fetch(response, 'original_language'),
		'User_Rating': str(Utils.fetch(response, 'rating')),
		'Votes': Utils.fetch(response, 'vote_count'),
		'Status': translate_status(Utils.fetch(response, 'status')),
		'path': 'plugin://'+str(addon_ID())+'?info=extendedtvinfo&&id=%s' % str(tvshow_id),
		'trailer': 'plugin://'+str(addon_ID())+'?info=playtvtrailer&&id=%s' % str(tvshow_id),
		'ShowType': Utils.fetch(response, 'type'),
		'homepage': Utils.fetch(response, 'homepage'),
		'last_air_date': Utils.fetch(response, 'last_air_date'),
		'first_air_date': Utils.fetch(response, 'first_air_date'),
		'TotalEpisodes': Utils.fetch(response, 'number_of_episodes'),
		'TotalSeasons': Utils.fetch(response, 'number_of_seasons'),
		'in_production': Utils.fetch(response, 'in_production'),
		'Release_Date': Utils.fetch(response, 'first_air_date'),
		'Premiered': Utils.fetch(response, 'first_air_date')
		}
	tvshow.update(artwork)
	if dbid:
		local_item = local_db.get_tvshow_from_db(dbid)
		tvshow.update(local_item)
	else:
		tvshow = local_db.merge_with_local_tvshow_info([tvshow])[0]
	tvshow['Rating'] = Utils.fetch(response, 'vote_average')

	pop_list = []
	for idx, i in enumerate(response['recommendations']['results']):
		if int(i.get('vote_count',0)) < 150:
			pop_list.append(idx)
	for i in reversed(pop_list):
		response['recommendations']['results'].pop(i)

	listitems = {
		'actors': handle_tmdb_people(response['credits']['cast']),
		'similar': handle_tmdb_tvshows(response['recommendations']['results']),
		'studios': handle_tmdb_misc(response['production_companies']),
		'networks': handle_tmdb_misc(response['networks']),
		'certifications': handle_tmdb_misc(response['content_ratings']['results']),
		'crew': handle_tmdb_people(response['credits']['crew']),
		'genres': handle_tmdb_misc(response['genres']),
		'keywords': handle_tmdb_misc(response['keywords']['results']),
		'videos': videos,
		'seasons': handle_tmdb_seasons(response['seasons']),
		'images': handle_tmdb_images(response['images']['posters']),
		'backdrops': handle_tmdb_images(response['images']['backdrops'])
		}
	return (tvshow, listitems)

def extended_season_info(tvshow_id, season_number):
	if not tvshow_id or not season_number:
		return None
	session_str = ''
	#tvshow = get_tmdb_data('tv/%s?append_to_response=alternative_titles,content_ratings,credits,external_ids,images,keywords,rating,similar,translations,videos&language=%s&include_image_language=en,null,%s&%s' % (tvshow_id, xbmcaddon.Addon().getSetting('LanguageID'), xbmcaddon.Addon().getSetting('LanguageID'), session_str), 99999)
	tvshow = get_tmdb_data('tv/%s?append_to_response=alternative_titles,content_ratings,credits,external_ids,images,keywords,rating,similar,videos&language=%s&include_image_language=en,null,%s&%s' % (tvshow_id, xbmcaddon.Addon().getSetting('LanguageID'), xbmcaddon.Addon().getSetting('LanguageID'), session_str), 99999)
	response = get_tmdb_data('tv/%s/season/%s?append_to_response=videos,images,external_ids,credits&language=%s&include_image_language=en,null,%s&' % (tvshow_id, season_number, xbmcaddon.Addon().getSetting('LanguageID'), xbmcaddon.Addon().getSetting('LanguageID')), 7)
	dbid = Utils.fetch(tvshow, 'dbid')
	tmdb_id = Utils.fetch(tvshow, 'id')
	external_ids = Utils.fetch(tvshow, 'external_ids')
	year = Utils.get_year(Utils.fetch(tvshow, 'first_air_date'))
	if external_ids:
		imdb_id = Utils.fetch(external_ids, 'imdb_id')
		freebase_id = Utils.fetch(external_ids, 'freebase_id')
		tvdb_id = Utils.fetch(external_ids, 'tvdb_id')
		tvrage_id = Utils.fetch(external_ids, 'tvrage_id')
	if not response:
		Utils.notify('Could not find season info')
		return None
	if response.get('name', False):
		title = response['name']
	else:
		title = 'Specials' if season_number == '0' else 'Season %s' % season_number
	season = {
		'SeasonDescription': Utils.clean_text(response['overview']),
		'Plot': Utils.clean_text(response['overview']),
		'TVShowTitle': Utils.fetch(tvshow, 'name'),
		'title': title,
		'dbid': dbid,
		'imdb_id': imdb_id,
		'tmdb_id': tmdb_id,
		'tvdb_id': tvdb_id,
		'tvrage_id': tvrage_id,
		'year': year,
		'season': season_number,
		'path': 'plugin://'+str(addon_ID())+'?info=seasoninfo&tvshow=%s&season=%s' % (Utils.fetch(tvshow, 'name'), season_number),
		'release_date': response['air_date'],
		'AirDate': response['air_date']
		}
	artwork = get_image_urls(poster=response.get('poster_path'))
	season.update(artwork)
	videos = handle_tmdb_videos(response['videos']['results']) if 'videos' in response else []
	listitems = {
		'actors': handle_tmdb_people(response['credits']['cast']),
		'crew': handle_tmdb_people(response['credits']['crew']),
		'videos': videos,
		'episodes': handle_tmdb_episodes(response['episodes']),
		'images': handle_tmdb_images(response['images']['posters'])
		}
	return (season, listitems)

def extended_episode_info(tvshow_id, season, episode, cache_time=7):
	if not tvshow_id or not episode:
		return None
	if not season:
		season = 0
	session_str = ''
	#tvshow = get_tmdb_data('tv/%s?append_to_response=alternative_titles,content_ratings,credits,external_ids,images,keywords,rating,similar,translations,videos&language=%s&include_image_language=en,null,%s&%s' % (tvshow_id, xbmcaddon.Addon().getSetting('LanguageID'), xbmcaddon.Addon().getSetting('LanguageID'), session_str), 99999)
	tvshow = get_tmdb_data('tv/%s?append_to_response=alternative_titles,content_ratings,credits,external_ids,images,keywords,rating,similar,videos&language=%s&include_image_language=en,null,%s&%s' % (tvshow_id, xbmcaddon.Addon().getSetting('LanguageID'), xbmcaddon.Addon().getSetting('LanguageID'), session_str), 99999)
	response = get_tmdb_data('tv/%s/season/%s/episode/%s?append_to_response=credits,runtime,external_ids,images,rating,videos&language=%s&include_image_language=en,null,%s&%s&' % (tvshow_id, season, episode, xbmcaddon.Addon().getSetting('LanguageID'), xbmcaddon.Addon().getSetting('LanguageID'), session_str), cache_time)
	tmdb_id = Utils.fetch(tvshow, 'id')
	TVShowTitle = Utils.fetch(tvshow, 'name')
	external_ids = Utils.fetch(tvshow, 'external_ids')
	year = Utils.get_year(Utils.fetch(tvshow, 'first_air_date')),
	if external_ids:
		imdb_id = Utils.fetch(external_ids, 'imdb_id')
		freebase_id = Utils.fetch(external_ids, 'freebase_id')
		tvdb_id = Utils.fetch(external_ids, 'tvdb_id')
		tvrage_id = Utils.fetch(external_ids, 'tvrage_id')
	videos = handle_tmdb_videos(response['videos']['results']) if 'videos' in response else []
	try:
		actors = handle_tmdb_people(response['credits']['cast'])
	except:
		actors = []
	try:
		crew = handle_tmdb_people(response['credits']['crew'])
	except:
		crew = []
	try:
		guest_stars = handle_tmdb_people(response['credits']['guest_stars'])
	except:
		guest_stars = []
	try:
		images = handle_tmdb_images(response['images']['stills'])
	except:
		images = []
	try: overview = Utils.clean_text(response['overview'])
	except KeyError: overview = ''
	try: runtime = response['runtime']
	except KeyError: runtime = None
	answer = {
		'SeasonDescription': overview,
		'Plot': overview,
		'TVShowTitle': TVShowTitle,
		'tvshow_id': tmdb_id,
		'tvdb_id': tvdb_id,
		'actors': actors,
		'path': 'plugin://'+str(addon_ID())+'?info=extendedepisodeinfo&tvshow_id=%s&season=%s&episode=%s' % (tvshow_id, season, episode),
		'crew': crew,
		'runtime': runtime,
		'guest_stars': guest_stars,
		'videos': videos,
		'images': images
		}
	#response = {'status_code': 7, 'status_message': 'Invalid API key: You must be granted a valid key.', 'success': False}
	ep = (handle_tmdb_episodes([response])[0], answer)
	ep[0]['poster'] = 'https://image.tmdb.org/t/p/w342' + tvshow['poster_path']
	ep[0]['thumb'] = 'https://image.tmdb.org/t/p/w342' + tvshow['poster_path']
	try: 
		ep[0]['fanart'] = ep[0]['still_original']
	except: 
		ep[0]['fanart'] = 'https://image.tmdb.org/t/p/w342' + tvshow['backdrop_path']
		#xbmc.log(str(ep[0])+'===>PHIL', level=xbmc.LOGINFO)
		#xbmc.log(str(tvshow)+'===>PHIL', level=xbmc.LOGINFO)
		pass
	ep[0]['TVShowTitle'] = TVShowTitle
	ep[0]['status'] = tvshow['status']
	#xbmc.log(str(response)+'===>get_trakt_playback', level=xbmc.LOGINFO)
	#xbmc.log(str(tvshow)+'===>get_trakt_playback', level=xbmc.LOGINFO)
	if ep[0]['episode'] == '':
		season_dict = extended_season_info(tvshow_id, season)
		ep[1]['actors'] = season_dict[1]['actors']
		ep[1]['crew'] = season_dict[1]['crew']
		#ep[1]['guest_stars'] = season[1]['guest_stars']
		ep[0]['season'] = int(season)
		ep[0]['episode'] = int(episode)
		ep[0]['Plot'] = season_dict[1]['episodes'][int(episode)-1]['Description']
		ep[0]['Description'] = season_dict[1]['episodes'][int(episode)-1]['Description']
		ep[0]['Votes'] = season_dict[1]['episodes'][int(episode)-1]['Votes']
		ep[0]['Rating'] = season_dict[1]['episodes'][int(episode)-1]['Rating']
		ep[0]['id'] = season_dict[1]['episodes'][int(episode)-1]['id']
		ep[0]['production_code'] = season_dict[1]['episodes'][int(episode)-1]['production_code']
		ep[0]['release_date'] = season_dict[1]['episodes'][int(episode)-1]['release_date']
		ep[0]['title'] = season_dict[1]['episodes'][int(episode)-1]['title']
		ep[0]['still'] = season_dict[1]['episodes'][int(episode)-1]['still'] 
		ep[0]['still_original'] = season_dict[1]['episodes'][int(episode)-1]['still_original'] 
		ep[0]['still_small'] = season_dict[1]['episodes'][int(episode)-1]['still_small'] 
		ep[0]['thumb'] = season_dict[1]['episodes'][int(episode)-1]['thumb'] 
		ep[0]['poster'] = 'https://image.tmdb.org/t/p/w342/' + tvshow['poster_path']
		ep[1]['images'] = []
		ep[1]['images'].append({'aspectratio': 1.778,
			'iso_639_1': None,
			'original': season_dict[1]['episodes'][int(episode)-1]['still_original'] ,
			'poster': season_dict[1]['episodes'][int(episode)-1]['still'],
			'poster_original': season_dict[1]['episodes'][int(episode)-1]['still_original'],
			'poster_small': season_dict[1]['episodes'][int(episode)-1]['still_small'], 
			'thumb': season_dict[1]['episodes'][int(episode)-1]['thumb'],
			'vote_average': 0.0})
	#return (handle_tmdb_episodes([response])[0], answer)
	ep[0]['year'] = ep[0]['release_date'][:4]
	return ep

def extended_actor_info(actor_id):
	if not actor_id:
		return None
	response = get_tmdb_data('person/%s?append_to_response=tv_credits,movie_credits,combined_credits,images,tagged_images&' % actor_id, 1)
	tagged_images = []
	if 'tagged_images' in response:
		tagged_images = handle_tmdb_tagged_images(response['tagged_images']['results'])
	listitems = {
		'movie_roles': handle_tmdb_movies(response['movie_credits']['cast']),
		'tvshow_roles': handle_tmdb_tvshows(response['tv_credits']['cast']),
		'movie_crew_roles': handle_tmdb_movies(response['movie_credits']['crew']),
		'tvshow_crew_roles': handle_tmdb_tvshows(response['tv_credits']['crew']),
		'tagged_images': tagged_images,
		'images': handle_tmdb_images(response['images']['profiles'])
		}
	info = handle_tmdb_people([response])[0]
	info['DBMovies'] = str(len([d for d in listitems['movie_roles'] if 'dbid' in d]))
	return (info, listitems)

def translate_status(status_string):
	translations = {
		'released': 'Released',
		'post production': 'Post production',
		'in production': 'In production',
		'ended': 'Ended',
		'returning series': 'Continuing',
		'planned': 'Planned'
		}
	if status_string.lower() in translations:
		return translations[status_string.lower()]
	else:
		return status_string

def get_keywords(movie_id):
	response = get_tmdb_data('movie/%s?append_to_response=alternative_titles,credits,images,keywords,releases,videos,translations,similar,reviews,rating&include_image_language=en,null,%s&language=%s&' % (movie_id, xbmcaddon.Addon().getSetting('LanguageID'), xbmcaddon.Addon().getSetting('LanguageID')), 30)
	keywords = []
	if 'keywords' in response:
		for keyword in response['keywords']['keywords']:
			keyword_dict = {
				'id': Utils.fetch(keyword, 'id'),
				'name': keyword['name']
				}
			keywords.append(keyword_dict)
	return keywords

def get_tmdb_shows(tvshow_type):
	response = get_tmdb_data('tv/%s?language=%s&' % (tvshow_type, xbmcaddon.Addon().getSetting('LanguageID')), 0.3)
	if 'results' in response:
		return handle_tmdb_tvshows(response['results'], False, None)
	else:
		return []

def get_tmdb_movies(movie_type):
	response = get_tmdb_data('movie/%s?language=%s&' % (movie_type, xbmcaddon.Addon().getSetting('LanguageID')), 0.3)
	if 'results' in response:
		return handle_tmdb_movies(response['results'], False, None)
	else:
		return []

def get_set_movies(set_id):
	response = get_tmdb_data('collection/%s?language=%s&append_to_response=images&include_image_language=en,null,%s&' % (set_id, xbmcaddon.Addon().getSetting('LanguageID'), xbmcaddon.Addon().getSetting('LanguageID')), 14)
	if response['parts'] == []:
		response2 = get_tmdb_data('collection/%s?' % (set_id), 14)
		response['parts'] = response2['parts']
	if response['parts'] == []:
		response2 = get_tmdb_data('collection/%s?&language=NULL&' % (set_id), 14)
		response['parts'] = response2['parts']
	if response:
		artwork = get_image_urls(poster=response.get('poster_path'), fanart=response.get('backdrop_path'))
		info = {
			'label': response['name'],
			'overview': response['overview'],
			'id': response['id']
			}
		info.update(artwork)
		return handle_tmdb_movies(response.get('parts', [])), info
	else:
		return [], {}


def get_person_movies(person_id):
	response = get_tmdb_data('person/%s/credits?language=%s&' % (person_id, xbmcaddon.Addon().getSetting('LanguageID')), 14)
	if 'crew' in response:
		return handle_tmdb_movies(response['crew'])
	else:
		return []

def get_person(person_id):
	response = get_tmdb_data('person/%s?language=%s&append_to_response=combined_credits&' % (person_id, xbmcaddon.Addon().getSetting('LanguageID')), 14)
	listitems = handle_tmdb_multi_search(response['combined_credits']['cast'])
	listitems += handle_tmdb_multi_search(response['combined_credits']['crew'])
	return listitems

def search_media(media_name=None, year='', media_type='movie'):
	search_query = Utils.url_quote('%s %s' % (media_name, year))
	if not search_query:
		return None
	response = get_tmdb_data('search/%s?query=%s&language=%s&include_adult=%s&' % (media_type, search_query, xbmcaddon.Addon().getSetting('LanguageID'), xbmcaddon.Addon().getSetting('include_adults')), 1)
	if not response == 'Empty':
		for item in response['results']:
			if item['id']:
				return item['id']
	return None

def get_imdb_id_from_movie_id(movie_id=None, cache_time=14):
	if not movie_id:
		return None
	session_str = ''
	response = get_tmdb_data('movie/%s?&language=%s,null,%s&%s' % (movie_id, xbmcaddon.Addon().getSetting('LanguageID'), xbmcaddon.Addon().getSetting('LanguageID'), session_str), cache_time)
	if not response:
		return False
	imdb_id = Utils.fetch(response, 'imdb_id')
	return imdb_id

def get_tvshow_ids(tvshow_id=None, cache_time=14):
	if not tvshow_id:
		return None
	session_str = ''
	response = get_tmdb_data('tv/%s?append_to_response=external_ids&language=%s&include_image_language=en,null,%s&%s' % (tvshow_id, xbmcaddon.Addon().getSetting('LanguageID'), xbmcaddon.Addon().getSetting('LanguageID'), session_str), cache_time)
	if not response:
		return False
	external_ids = Utils.fetch(response, 'external_ids')
	return external_ids



def get_trakt_playback(trakt_type=None):
	import urllib.parse
	from datetime import datetime
	from datetime import timedelta
	from resources.lib.library import get_trakt_data
	date_format = "%Y-%m-%dT%H:%M:%S.%fZ"
	now = datetime.strftime(datetime.now() + timedelta(days=1), date_format)
	year_minus_one = datetime.strftime(datetime.now() - timedelta(days=1*180), date_format)
	if trakt_type == 'tv':
		url = 'https://api.trakt.tv/sync/playback/episodes?start_at=%s&end_at=%s' % (urllib.parse.quote(year_minus_one),urllib.parse.quote(now))
		response = get_trakt_data(url=url, cache_days=0.0001, folder='Trakt')
		#xbmc.log(str(response)+'===>get_trakt_playback', level=xbmc.LOGINFO)
		return response
	else:
		url = 'https://api.trakt.tv/sync/playback/movies?start_at=%s&end_at=%s' % (urllib.parse.quote(year_minus_one),urllib.parse.quote(now))
		response = get_trakt_data(url=url, cache_days=0.0001, folder='Trakt')
		#xbmc.log(str(response)+'===>get_trakt_playback', level=xbmc.LOGINFO)
		return response

def update_trakt_playback(trakt_type=None,tmdb_id=None,episode=None,season=None):
	from resources.lib.library import trak_auth
	import requests
	if trakt_type == 'tv':
		response = get_trakt_playback('tv')
		item_id = tmdb_id
		episode = str(episode)
		season = str(season)
		DBTYPE = 'episode'
	else:
		response = get_trakt_playback('movie')
		item_id = tmdb_id
		DBTYPE = 'movie'
	for i in response:
		if DBTYPE == 'episode':
			if str(i['show']['ids']['tmdb']) == str(item_id):
				if str(i['episode']['number']) == str(episode) and str(i['episode']['season']) == str(season):
					play_id = i['id']
					url = 'https://api.trakt.tv/sync/playback/' + str(play_id)
					response = requests.delete(url, headers=trak_auth())
		else:
			if str(i['movie']['ids']['tmdb']) == str(item_id):
				play_id = i['id']
				url = 'https://api.trakt.tv/sync/playback/' + str(play_id)
				response = requests.delete(url, headers=trak_auth())	
	return response

def get_watching_user():
	from resources.lib.library import get_trakt_data
	trakt_slug = xbmcaddon.Addon().getSetting('trakt_slug')
	url = 'https://api.trakt.tv/users/%s/watching' % str(trakt_slug)
	response = get_trakt_data(url=url, cache_days=0.0001, folder='Trakt')
	return response



def get_imdb_language_api(imdb_id=None, cache_days=14, folder='IMDB'):
	import requests
	import json
	url = "https://api.graphql.imdb.com/"
	headers = {
		"Content-Type": "application/json",
		"Accept": "application/json",
		"User-Agent": "Mozilla/5.0"
	}
	query = """ query ($id: ID!) { title(id: $id) { spokenLanguages { spokenLanguages { id text } } countriesOfOrigin { countries(limit: 1) { id } } } } """
	variables = {"id": imdb_id}
	payload = {"query": query, "variables": variables}
	imdb_url = ('https://www.imdb.com/title/' + str(imdb_id) + '/get_imdb_language').encode('utf-8')
	imdb_header = headers
	try:
		db_result, expired_db_result = Utils.query_db(connection=Utils.db_con,url=imdb_url, cache_days=cache_days, folder=folder, headers=imdb_header)
	except:
		db_result, expired_db_result = None, None
	if db_result:
		return db_result
	else:
		response = requests.post(url, headers=headers, data=json.dumps(payload))
		if response.status_code != 200:
			return []
		data = response.json()
		spoken = data.get("data", {}).get("title", {}).get("spokenLanguages", {}).get("spokenLanguages", [])
		countries = data.get("data", {}).get("title", {}).get("countriesOfOrigin", {}).get("countries", [])
		language_list = [lang.get("text") for lang in spoken if "text" in lang]
		english_speaking_countries = {"US", "UK", "GB", "CA", "AU", "NZ", "IE", "ZA"}
		country_id = countries[0].get("id") if countries else ""
		if "English" in language_list and country_id in english_speaking_countries:
			language_list = ["English"] + [l for l in language_list if l != "English"]
		results = language_list
	#Utils.write_db(connection=Utils.db_con,url=url, cache_days=cache_days, folder=folder,cache_val=results)
	#if not results:
	#	return []
	#else:
	#	return results

	if not results or len(results) == 0:
		if expired_db_result == None:
			return []
		if len(expired_db_result) > 0:
			Utils.write_db(connection=Utils.db_con,url=url, cache_days=0.25, folder=folder,cache_val=expired_db_result)
			return expired_db_result
		return []
	else:
		Utils.write_db(connection=Utils.db_con,url=url, cache_days=cache_days, folder=folder,cache_val=results)
	return results

def imdb_base_title_card(imdb_id: str):
	url = "https://api.graphql.imdb.com/"
	headers = {
		"Content-Type": "application/json",
		"User-Agent": "Mozilla/5.0"
	}
	query = """
	query Title_Summary_Prompt_From_Base($id: ID!) { title(id: $id) { ...BaseTitleCard } }
	fragment BaseTitleCard on Title { 
		id titleText { text } 
		titleType { id text canHaveEpisodes displayableProperty { value { plainText } } }
		originalTitleText { text } 
		primaryImage { id width height url caption { plainText } }
		releaseYear { year endYear }
		ratingsSummary { aggregateRating voteCount }
		runtime { seconds }
		certificate { rating }
		canRate { isRatable }
		titleGenres { genres(limit: 3) { genre { text } } } 
		}
	"""
	variables = {
		"id": imdb_id
	}
	response = requests.post(url, json={"query": query, "variables": variables}, headers=headers)
	if response.status_code == 200:
		return response.json()
	else:
		raise Exception(f"Query failed with status code {response.status_code}: {response.text}")

def get_imdb_language(imdb_id=None, cache_days=14, folder='IMDB'):
	Utils.log('get_imdb_language_api')
	results = get_imdb_language_api(imdb_id=imdb_id, cache_days=cache_days, folder='IMDB')
	return results


def get_imdb_season_episodes(imdb_id, season, first=99):
	import requests
	import json
	url = "https://api.graphql.imdb.com/"
	headers = {
		"Content-Type": "application/json",
		"Accept": "application/json",
		"User-Agent": "Mozilla/5.0"
	}
	query = """query SeasonEpisodes($id: ID!, $season: String!, $first: Int!, $originalTitleText: Boolean!) { title(id: $id) { episodes { episodes(first: $first, filter: { includeSeasons: [$season] }, sort: { by: EPISODE_THEN_RELEASE, order: ASC }) { edges { node { id titleText { text } plot { plotText { plaidHtml(showOriginalTitleText: $originalTitleText) } } releaseDate { year month day } ratingsSummary { aggregateRating voteCount } primaryImage { url } series { displayableEpisodeNumber { episodeNumber { displayableProperty { value { plainText } } } displayableSeason { displayableProperty { value { plainText } } } } } } } } } } }"""
	variables = {
		"id": imdb_id,
		"season": str(season),
		"first": first,
		"originalTitleText": True
	}
	payload = {
		"query": query,
		"variables": variables
	}
	response = requests.post(url, headers=headers, data=json.dumps(payload))
	response.raise_for_status()
	data = response.json()
	edges = data.get("data", {}).get("title", {}).get("episodes", {}).get("episodes", {}).get("edges", [])
	episodes = []
	for edge in edges:
		try: 
			node = edge.get("node", {})
			displayable_episode_number = node.get("series", {}).get("displayableEpisodeNumber", {})
			episode_number = displayable_episode_number.get("episodeNumber", {}).get("displayableProperty", {}).get("value", {}).get("plainText")
			season_number = displayable_episode_number.get("displayableSeason", {}).get("displayableProperty", {}).get("value", {}).get("plainText")
			plot_html = node.get("plot", {}).get("plotText", {}).get("plaidHtml")
			episodes.append({
				"id": node.get("id"),
				"title": node.get("titleText", {}).get("text"),
				"plot": plot_html,
				"release_date": node.get("releaseDate"),
				"rating": node.get("ratingsSummary", {}).get("aggregateRating"),
				"vote_count": node.get("ratingsSummary", {}).get("voteCount"),
				"image_url": node.get("primaryImage", {}).get("url"),
				"episode_number": episode_number,
				"season_number": season_number
			})
		except: continue
	return episodes

def get_imdb_recommendations_api(imdb_id=None, return_items=False, cache_days=14, folder='IMDB'):
	import requests
	import json
	url = "https://api.graphql.imdb.com/"
	headers = {
		"Content-Type": "application/json",
		"Accept": "application/json",
		"User-Agent": "Mozilla/5.0"
	}

	base_title_card = """fragment BaseTitleCard on Title { id titleText { text } primaryImage { url } releaseYear { year } titleType { text } } """
	query = f""" query MoreLikeThis($id: ID!) {{ title(id: $id) {{ ...TMD_MoreLikeThis }} }} fragment TMD_MoreLikeThis on Title {{ id isAdult moreLikeThisTitles(first: 12) {{ edges {{ node {{ ...BaseTitleCard }} }} }} }}
	{base_title_card}
	"""
	variables = {
		"id": imdb_id
	}
	payload = {
		"query": query,
		"variables": variables
	}

	imdb_url = 'https://www.imdb.com/title/' + str(imdb_id)
	imdb_url2 = 'https://www.imdb.com/title/' + str(imdb_id) + '[2]'
	imdb_url = str(imdb_url + '/get_imdb_recommendations').encode('utf-8')
	imdb_url2 = str(imdb_url2 + '/get_imdb_recommendations').encode('utf-8')
	imdb_header = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'}

	try: 
		db_result, expired_db_result = Utils.query_db(connection=Utils.db_con,url=imdb_url, cache_days=cache_days, folder=folder, headers=imdb_header)
	except:
		db_result, expired_db_result = None, None
	if db_result:
		return db_result
	else:
		response = requests.post(url, headers=headers, data=json.dumps(payload))
		if response.status_code != 200:
			raise Exception(f"Query failed with status code {response.status_code}: {response.text}")
		data = response.json()
		edges = data.get("data", {}).get("title", {}).get("moreLikeThisTitles", {}).get("edges", [])
		movies = [edge["node"]["id"] for edge in edges if "node" in edge and "id" in edge["node"]]

		if return_items == False:
			results2 = movies
			Utils.write_db(connection=Utils.db_con,url=imdb_url, cache_days=cache_days, folder=folder,cache_val=results)
			if not results2:
				return []
			return results2
		else:
			results = get_imdb_watchlist_items(movies=movies, limit=0, imdb_url=imdb_url.decode('utf-8'))
	#Utils.write_db(connection=Utils.db_con,url=url, cache_days=cache_days, folder=folder,cache_val=results)
	#if not results:
	#	return []
	#else:
	#	return results

	if not results or len(results) == 0:
		if expired_db_result == None:
			return []
		if len(expired_db_result) > 0:
			Utils.write_db(connection=Utils.db_con,url=url, cache_days=0.25, folder=folder,cache_val=expired_db_result)
			return expired_db_result
		return []
	else:
		Utils.write_db(connection=Utils.db_con,url=url, cache_days=cache_days, folder=folder,cache_val=results)
	return results


def get_imdb_recommendations(imdb_id=None, return_items=False, cache_days=14, folder='IMDB'):
	Utils.log('get_imdb_recommendations_api')
	movies = get_imdb_recommendations_api(imdb_id, return_items=return_items, cache_days=cache_days, folder='IMDB')
	return movies


def get_imdb_list_ids_api2(list_str=None):
	import requests, json
	url = "https://api.graphql.imdb.com/"
	headers = {
		"Content-Type": "application/json",
		"User-Agent": "Mozilla/5.0",
		"x-imdb-client-name": "imdb-web-next"
	}

	base_title_card = """
	fragment BaseTitleCard on Title { id titleText { text } primaryImage { url } releaseYear { year } titleType { text } } """
	query = f""" query VideoPlaylistWidgetList($id: ID!, $first: Int!, $after: ID) {{   list(id: $id) {{ items(first: $first, after: $after) {{   total   pageInfo {{  endCursor hasNextPage   }}   edges {{ node {{   listItem {{ ... on Title {{   ...BaseTitleCard }}   }} }}   }} }}   }} }} {base_title_card} """

	all_items = []
	after_cursor = None
	total = None

	while True:
		variables = {
			"id": list_str,
			"first": 1000,
			"after": after_cursor
		}
		payload = {"query": query,"variables": variables}
		#response = requests.post(url, json={"query": query, "variables": variables}, headers=headers)
		response = requests.post(url, headers=headers, data=json.dumps(payload))
		if response.status_code != 200:
			raise Exception(f"Query failed with status code {response.status_code}: {response.text}")

		data = response.json()
		items_data = data.get("data", {}).get("list", {}).get("items", {})
		if total is None:
			total = items_data.get("total", 0)

		edges = items_data.get("edges", [])
		for edge in edges:
			node = edge.get("node", {})
			title = node.get("listItem", {})
			if title:
				all_items.append({
					"id": title.get("id"),
					"title": title.get("titleText", {}).get("text"),
					"image": title.get("primaryImage").get("url") if title.get("primaryImage") else None,
					"year": title.get("releaseYear").get("year") if title.get("releaseYear") else None,
					"type": title.get("titleType", {}).get("text")
				})

		page_info = items_data.get("pageInfo", {})
		if not page_info.get("hasNextPage"):
			break
		after_cursor = page_info.get("endCursor")
	movies = []
	for i in all_items:
		movies.append(i['id'])
	#return {"total": total,"fetched": len(all_items),"items": all_items}
	return movies


def get_imdb_list_ids(list_str=None, limit=0):
	Utils.log(list_str)
	if 'ls_top_1000' == list_str:
		movies = imdb_top_1000()
		return movies

	if 'ls_imdb_coming_soon' == list_str:
		country = xbmcaddon.Addon().getSetting('imdb_country')
		movies = imdb_coming_soon(country=country, coming_soon_type="MOVIE")
		return movies

	if list_str in ['ls_popular','ls_trending','ls_anticipated','ls_recent']:
		Utils.log(list_str)
		movies_list,types_list = imdb_multi(list_str)
		return movies_list,types_list

	if 'ls_imdb_movies_near_you' == list_str:
		from datetime import date
		from dateutil.relativedelta import relativedelta
		today = date.today()
		one_month_later = today + relativedelta(months=1)
		one_month_earlier = today + relativedelta(months=-1)

		start_date = one_month_earlier.strftime("%Y-%m-%d")
		end_date = one_month_later.strftime("%Y-%m-%d")

		imdb_lat = xbmcaddon.Addon().getSetting('imdb_lat')
		imdb_long = xbmcaddon.Addon().getSetting('imdb_long')
		imdb_radius = xbmcaddon.Addon().getSetting('imdb_radius')
		movies = imdb_movies_near_you(latitude=float(imdb_lat),longitude=float(imdb_long),radius_meters=int(imdb_radius),start_date=start_date,end_date=end_date)
		return movies

	else:
		Utils.log('get_imdb_list_ids_api2  ' + str(list_str))
		movies = get_imdb_list_ids_api2(list_str)
		return movies




def imdb_top_1000():
	import requests
	API_URL = "https://graphql.prod.api.imdb.a2z.com/"
	HEADERS = {
		'Referer': 'https://www.imdb.com/',
		'Origin': 'https://www.imdb.com',
		'User-Agent': 'Mozilla/5.0',
		'Content-Type': 'application/json'
	}

	query = '''query AdvancedTitleSearch($first: Int!,$after: String,$originCountryConstraint: OriginCountrySearchConstraint,$rankedTitleListConstraint: RankedTitleListSearchConstraint,$sortBy: AdvancedTitleSearchSortBy!,$sortOrder: SortOrder!) { advancedTitleSearch(first: $first,after: $after,constraints: { originCountryConstraint: $originCountryConstraint,rankedTitleListConstraint: $rankedTitleListConstraint },sort: { sortBy: $sortBy,sortOrder: $sortOrder }) { ...AdvancedTitleSearchConnection } } fragment AdvancedTitleSearchConnection on AdvancedTitleSearchConnection { total pageInfo { endCursor hasNextPage } edges { node { title { id titleText { text } originalTitleText { text } ratingsSummary { aggregateRating voteCount } releaseYear { year } primaryImage { url } } } } }'''

	variables = { "first": 1000, "after": None, "locale": "en-US", "originCountryConstraint": { "excludeCountries": ["IN"] }, "rankedTitleListConstraint": { "allRankedTitleLists": [{ "rankRange": {"max": 1000}, "rankedTitleListType": "TOP_RATED_MOVIES" }], "excludeRankedTitleLists": [] }, "sortBy": "USER_RATING", "sortOrder": "DESC" }

	all_titles = []
	while True:
		response = requests.post(API_URL, headers=HEADERS, json={
			"operationName": "AdvancedTitleSearch",
			"query": query,
			"variables": variables
		})
		#print(response.text)
		data = response.json()["data"]["advancedTitleSearch"]

		titles = [edge["node"]["title"]["id"] for edge in data["edges"]]
		all_titles.extend(titles)

		if not data["pageInfo"]["hasNextPage"]:
			break

		variables["after"] = data["pageInfo"]["endCursor"]

	return all_titles




def imdb_userListSearch_api(ur_id=None):
	Utils.log('imdb_userListSearch_api')
	user_profile_id = ur_id

	import requests, json, re

	def get_urconst_from_profile_id(profile_id):
		url = "https://api.graphql.imdb.com/"
		headers = {"Content-Type": "application/json", "User-Agent": "Mozilla/5.0", "x-imdb-client-name": "imdb-web-next"}
		query = """query RatingInsightsInterestTopRatedWithProfileId($profileId: ID) { userProfile(input: { profileId: $profileId }) { userId } }"""
		variables = {"profileId": profile_id}
		try:
			response = requests.post(url, headers=headers, data=json.dumps({"query": query, "variables": variables}, separators=(',', ':')))
			#Utils.log(f"DEBUG RESPONSE: {response.text}")
			if response.status_code != 200: return f"Error: {response.status_code}"
			ur_const = response.json().get("data", {}).get("userProfile", {}).get("userId")
			return ur_const if ur_const else "UR ID not found"
		except Exception as e: return f"Failed: {str(e)}"

	def get_user_lists_via_search(ur_id):
		Utils.log('get_user_lists_via_search')
		url = "https://api.graphql.imdb.com/"
		headers = {"Content-Type": "application/json", "User-Agent": "Mozilla/5.0", "x-imdb-client-name": "imdb-web-next" }
		query = """query UserLists($ur_id: ID!, $after: ID) { userListSearch(first: 100, listOwnerUserId: $ur_id, after: $after) { edges { node { id name { originalText } items(first: 0) { total } 	author { nickName userId } } } pageInfo { hasNextPage endCursor } } }"""
		all_edges = []
		after_cursor = None
		nickname = "User"
		try:
			while True:
				variables = {"ur_id": ur_id, "after": after_cursor}
				response = requests.post(url, headers=headers, data=json.dumps({"query": query, "variables": variables}))
				#Utils.log(response.text)
				if response.status_code != 200: return None, f"Error: {response.status_code}"
				payload = response.json().get("data", {}).get("userListSearch", {})
				edges = payload.get("edges", [])
				if not edges and not all_edges: return None, "No public lists found"
				all_edges.extend(edges)
				if edges and nickname == "User":
					nickname = edges[0].get("node", {}).get("author", {}).get("nickName", "User")
				page_info = payload.get("pageInfo", {})
				if not page_info.get("hasNextPage"):
					break
				after_cursor = page_info.get("endCursor")
			imdb_list = {"imdb_list": []}
			for edge in all_edges:
				node = edge.get("node", {})
				list_id = node.get("id")
				list_name = node.get("name", {}).get("originalText", "Unnamed List")
				if list_name.lower() == 'watchlist':
					list_name = f"{nickname} Watchlist"
				list_count = node.get("items", {}).get("total", 0)
				imdb_list["imdb_list"].append({
					list_id: f"IMDB - {list_name} - {list_count}"
				})
			return nickname, imdb_list
		except Exception as e: return None, f"Failed: {str(e)}"
	ur_id = user_profile_id
	if ur_id[:2].lower() == 'ur':
		nickname, imdb_list = get_user_lists_via_search(ur_id)
	else:
		ur_id = get_urconst_from_profile_id(user_profile_id)
		nickname, imdb_list = get_user_lists_via_search(ur_id)
	return imdb_list

def get_imdb_userlists():
	imdb_id = xbmcaddon.Addon().getSetting('imdb_ur_id')
	Utils.log(imdb_id)
	if imdb_id == '':
		return None
	#imdb_list = get_imdb_userlists_search(imdb_id=imdb_id)
	#Utils.log(imdb_id)
	imdb_list = imdb_userListSearch_api(ur_id=imdb_id)
	return imdb_list

def get_user_watchlist_id(ur_list_str=None,return_dict=False):
	Utils.log('get_user_watchlist_id')
	user_profile_id = ur_list_str
	import requests, json, re
	def get_urconst_from_profile_id(profile_id):
		url = "https://api.graphql.imdb.com/"
		headers = {"Content-Type": "application/json", "User-Agent": "Mozilla/5.0", "x-imdb-client-name": "imdb-web-next"}
		query = """query RatingInsightsInterestTopRatedWithProfileId($profileId: ID) { userProfile(input: { profileId: $profileId }) { userId } }"""
		variables = {"profileId": profile_id}
		try:
			response = requests.post(url, headers=headers, data=json.dumps({"query": query, "variables": variables}, separators=(',', ':')))
			#print(f"DEBUG RESPONSE: {response.text}")
			if response.status_code != 200: return f"Error: {response.status_code}"
			ur_const = response.json().get("data", {}).get("userProfile", {}).get("userId")
			return ur_const if ur_const else "UR ID not found"
		except Exception as e: return f"Failed: {str(e)}"
	def get_watchlist_lsid_from_ur(ur_id):
		url = "https://api.graphql.imdb.com/"
		headers = {"Content-Type": "application/json", "User-Agent": "Mozilla/5.0", "x-imdb-client-name": "imdb-web-next"}
		# Corrected to WATCH_LIST and userId based on standard IMDb GraphQL field names
		query = """query WatchlistDiscovery($ur_id: ID!) { predefinedList(classType: WATCH_LIST, userId: $ur_id) { id items(first: 0) { total } } }"""
		variables = {"ur_id": ur_id}
		try:
			response = requests.post(url, headers=headers, data=json.dumps({"query": query, "variables": variables}))
			#print(f"DEBUG RESPONSE: {response.text}")
			if response.status_code != 200: return f"Error: {response.status_code}"
			data = response.json()
			ls_id = data.get("data", {}).get("predefinedList", {}).get("id")
			total = data.get("data", {}).get("predefinedList", {}).get("items",{}).get("total")
			ls_dict = {'ls_id': ls_id, 'name': 'watchlist', 'count': total}
			return ls_id,ls_dict if ls_id else "Watchlist not found (check if profile is public)"
		except Exception as e: return f"Failed: {str(e)}"
	ur_id = user_profile_id
	if ur_id[:2].lower() == 'ur':
		ls_id,ls_dict =get_watchlist_lsid_from_ur(ur_id)
	else:
		ur_id = get_urconst_from_profile_id(user_profile_id)
		ls_id,ls_dict =get_watchlist_lsid_from_ur(ur_id)
	if return_dict == False:
		return ls_id
	else:
		watchlist_dict = {}
		watchlist_dict['watchlist_id'] = ls_id
		watchlist_dict['ur_list_str'] = ur_id
		watchlist_dict['total'] = ls_dict['count']
		watchlist_dict['name'] = f"IMDB - {ur_id} Watchlist - " + str(ls_dict['count'])
		return watchlist_dict


def get_imdb_watchlist_ids_api2(ur_list_str=None, limit=0):
	list_id = get_user_watchlist_id(ur_list_str=ur_list_str)

	url = "https://api.graphql.imdb.com/"
	movies = get_imdb_list_ids_api2(list_str=list_id)
	return movies


def get_imdb_watchlist_ids(ur_list_str=None, limit=0):
	if ur_list_str:
		Utils.log('get_imdb_watchlist_ids_api2')
		movies = get_imdb_watchlist_ids_api2(ur_list_str)
		return movies


def imdb_coming_soon(country: str, coming_soon_type: str):
	#titles = imdb_coming_soon(country="GB", coming_soon_type="MOVIE")
	import requests, datetime
	API_URL = "https://graphql.prod.api.imdb.a2z.com/"
	HEADERS = {
		'Referer': 'https://www.imdb.com/',
		'Origin': 'https://www.imdb.com',
		'User-Agent': 'Mozilla/5.0',
		'Content-Type': 'application/json'
	}

	fragment = """
	fragment CalendarCard on Title {
		id titleText { text } originalTitleText { text } titleType { id text canHaveEpisodes } isAdult
		releaseDate { year month day country { id } displayableProperty { qualifiersInMarkdownList { plaidHtml } } }
		releaseDates( first: 10, filter: { countries: [$countryOverride], wideRelease: WIDE_RELEASE_ONLY } ) {
			edges { node { year month day country { id } displayableProperty { qualifiersInMarkdownList { plaidHtml } } } } }
		primaryImage { url height width caption { plainText } }
		titleGenres { genres(limit: 3) { genre { displayableProperty { value { plainText } } } } }
		principalCredits(filter: { categories: ["cast"] }) { credits { name { id nameText { text } } } } 
		releaseYear { endYear year } 
		series {displayableEpisodeNumber { episodeNumber { text } displayableSeason { season } } series { titleText { text } originalTitleText { text } } } } """

	query = f""" query CalendarPage( $comingSoonType: ComingSoonType!, $regionOverride: String!, $countryOverride: ID!, $releasingOnOrAfter: Date!, $releasingOnOrBefore: Date!, $disablePopularityFilter: Boolean!, 
		$after: ID ) {{ comingSoon( comingSoonType: $comingSoonType, first: 250, regionOverride: $regionOverride, releasingOnOrAfter: $releasingOnOrAfter, releasingOnOrBefore: $releasingOnOrBefore,
			disablePopularityFilter: $disablePopularityFilter, after: $after, sort: [ {{ sortBy: RELEASE_DATE, sortOrder: ASC }}, {{ sortBy: POPULARITY, sortOrder: ASC }} ] )
			{{ pageInfo {{ endCursor hasNextPage }} edges {{ node {{...CalendarCard }} }} }} }} {fragment} """

	today = datetime.datetime.utcnow().date()
	end_date = today + datetime.timedelta(days=360)

	variables = {
		"comingSoonType": coming_soon_type,
		"regionOverride": country,
		"countryOverride": country,
		"releasingOnOrAfter": today.isoformat(),
		"releasingOnOrBefore": end_date.isoformat(),
		"disablePopularityFilter": False,
		"isInPace": False,
		"after": None
	}

	all_titles = []
	while True:
		response = requests.post(API_URL, headers=HEADERS, json={ "operationName": "CalendarPage", "query": query, "variables": variables })
		#print(response.text)
		data = response.json()["data"]["comingSoon"]
		titles = [edge["node"]["id"] for edge in data["edges"]]
		all_titles.extend(titles)
		if not data["pageInfo"]["hasNextPage"]:
			break
		variables["after"] = data["pageInfo"]["endCursor"]

	return all_titles

def imdb_multi(list_name):
	import requests
	import json
	import datetime

	HEADERS = {
		"Content-Type": "application/json",
		"User-Agent": "Mozilla/5.0",
		"x-imdb-client-name": "imdb-web-next"
	}
	API_URL = "https://api.graphql.imdb.com/"

	BASE_TITLE_CARD_FRAGMENT = """ fragment BaseTitleCard on Title { id titleText { text } titleType { id text canHaveEpisodes displayableProperty { value { plainText } } } 
		originalTitleText { text } 
		primaryImage {id width height url  caption { plainText } }
		releaseYear { year endYear }
		ratingsSummary { aggregateRating voteCount }
		runtime { seconds }
		certificate { rating }
		canRate { isRatable }
		titleGenres { genres(limit: 3) { genre { text } } }
	}
	"""

	def gqlmin(q):
		return q.replace("	", "")

	def fetch_imdb_ids(category):
		if category not in ["trending", "anticipated", "popular", "recent"]:
			raise ValueError("Invalid category")

		today = datetime.date.today().isoformat()
		variables = {"limit": 300}
		if category == "anticipated":
			variables["queryFilter"] = {"releaseDateRange": {"start": today}}
		elif category == "popular":
			variables["queryFilter"] = {"releaseDateRange": {"end": today}}
		elif category == "recent":
			variables["queryFilter"] = {"contentTypes": ["TRAILER"]}

		if category == "trending":
			opname = "TrendingTitles"
			query = """ query TrendingTitles($limit: Int!, $paginationToken: String) { trendingTitles(limit: $limit, paginationToken: $paginationToken) { titles { ...BaseTitleCard }  paginationToken  } } """
		elif category == "recent":
			opname = "RecentVideos"
			query = """query RecentVideos($limit: Int!, $paginationToken: String, $queryFilter: RecentVideosQueryFilter!) { recentVideos(limit: $limit, paginationToken: $paginationToken, queryFilter: $queryFilter) { videos { primaryTitle { ...BaseTitleCard } } paginationToken } }"""
		else:
			opname = "PopularTitles"
			query = """query PopularTitles($limit: Int!, $paginationToken: String, $queryFilter: PopularTitlesQueryFilter!) {
				popularTitles(limit: $limit, paginationToken: $paginationToken, queryFilter: $queryFilter) { titles { ...BaseTitleCard  } paginationToken } }
			"""

		query += BASE_TITLE_CARD_FRAGMENT
		items = []
		items_types = []
		pages = 0
		pagination_token = None
		while len(items) < 300 and pages < 5:
			if pagination_token:
				variables["paginationToken"] = pagination_token
			payload = {
				"operationName": opname,
				"query": gqlmin(query),
				"variables": variables
			}
			response = requests.post(API_URL, headers=HEADERS, data=json.dumps(payload))
			print(response.text)
			if response.status_code != 200:
				raise Exception(f"Query failed: {response.status_code} - {response.text}")
			data = response.json().get("data", {})
			if category == "trending":
				result = data.get("trendingTitles", {})
				titles = result.get("titles", [])
				items.extend([t["id"] for t in titles if "id" in t])
				items_types.extend([t['titleType']["id"] for t in titles if "titleType" in t])
			elif category == "recent":
				result = data.get("recentVideos", {})
				videos = result.get("videos", [])
				items.extend([v["primaryTitle"]["id"] for v in videos if v.get("primaryTitle")])
				items_types.extend([t['titleType']["id"] for t in titles if "titleType" in t])
			else:
				result = data.get("popularTitles", {})
				titles = result.get("titles", [])
				items.extend([t["id"] for t in titles if "id" in t])
				items_types.extend([t['titleType']["id"] for t in titles if "titleType" in t])
			pagination_token = result.get("paginationToken")
			if not pagination_token:
				break
			pages += 1
		return items,items_types

	def imdb_movies_near_you(latitude,longitude,radius_meters,start_date,end_date,first=1000,sort_by="POPULARITY",sort_order="ASC"):
		import requests
		API_URL = "https://graphql.prod.api.imdb.a2z.com/"
		HEADERS = {
			'Referer': 'https://www.imdb.com/',
			'Origin': 'https://www.imdb.com',
			'User-Agent': 'Mozilla/5.0',
			'Content-Type': 'application/json'
		}

		query = '''query MoviesNearYou($first: Int!, $sort: AdvancedTitleSearchSort!, $constraints: AdvancedTitleSearchConstraints!) { advancedTitleSearch(first: $first, sort: $sort, constraints: $constraints) {edges {  node { title {  id   titleText { text }   ratingsSummary { aggregateRating voteCount }   releaseYear { year }  primaryImage { url } }   }  } total  } } '''

		variables = { "first": first, "sort": { "sortBy": sort_by, "sortOrder": sort_order },
			"constraints": { "inTheatersConstraint": { "dateTimeRange": { 
						"start": f"{start_date}T00:00:00.000Z",
						"end": f"{end_date}T00:00:00.000Z"
					}, "location": { "latLong": { "lat": str(latitude), "long": str(longitude)},"radiusInMeters": radius_meters } } } }

		response = requests.post(API_URL, headers=HEADERS, json={
			"operationName": "MoviesNearYou",
			"query": query,
			"variables": variables
		})

		def image_url(title_info):
			try:
				if "primaryImage" in title_info and "url" in title_info["primaryImage"]:
					image_url = title_info["primaryImage"]["url"]
				else:
					image_url = ''
				return image_url
			except: return ''

		data = response.json().get("data", {}).get("advancedTitleSearch", {})
		#print(response.text)
		movies = []
		movies_list = []
		types_list = []
		for edge in data.get("edges", []):
			title_info = edge["node"]["title"]
			#print(title_info)
			movies_list.append(title_info.get("id"))
			types_list.append('movie')
			movie = {
				"id": title_info.get("id"),
				"title": title_info.get("titleText", {}).get("text"),
				"rating": title_info.get("ratingsSummary", {}).get("aggregateRating"),
				"vote_count": title_info.get("ratingsSummary", {}).get("voteCount"),
				"release_year": title_info.get("releaseYear", {}).get("year"),
				"image_url": image_url(title_info)

			}
			movies.append(movie)

		return movies_list,types_list

	if list_name == 'ls_trending':
		movies_list,types_list = fetch_imdb_ids("trending")
	elif list_name == 'ls_anticipated':
		movies_list,types_list = fetch_imdb_ids("anticipated")
	elif list_name == 'ls_popular':
		movies_list,types_list = fetch_imdb_ids("popular")
	elif list_name == 'ls_recent':
		movies_list,types_list = fetch_imdb_ids("recent")
	return movies_list,types_list


def movies_pre_process(cache_days=7.0, folder='VOD', headers=False):
	import time
	import re
	from tools import clean_title
	movies_pre_processed = []
	now = time.time()
	url = 'movies_pre_processed'
	#hashed_url = hashlib.md5(url).hexdigest()
	#cache_seconds = int(cache_days * 86400.0)
	db_con = Utils.test_db()
	try:
		#Utils.tools_log(db_con)
		db_result, expired_db_result = Utils.query_db(connection=db_con,url=url, cache_days=cache_days, folder=folder, headers=headers)
		#Utils.tools_log(db_result)
	except:
		db_result, expired_db_result = None, None

	try: 
		db_result_flag = True if len(db_result)> 0 else False
	except: 
		db_result_flag = False
	if db_result_flag:
		#Utils.tools_log(db_result_flag,'movies_pre_process')
		return db_result
	else:
		movies = get_vod_allmovies()
		for x in movies:
			re_match = re.search(r"^(.*)\((\d{4})\)\s*$", x['title'])
			year = None
			if re_match:
				name = re_match.group(1).strip()
				try: year = re_match.group(2)
				except: year = None
				x['pre_processed_title'] = name
			else:
				x['pre_processed_title'] = x['title']
			if year == None:
				x['pre_processed_year'] = ''
			else:
				x['pre_processed_year'] = year
		
			x['pre_processed_title_lower'] = str(x['title']).lower()
			x['pre_processed_clean_title_lower'] = clean_title(str(x['title']).lower(), broken=2)
			movies_pre_processed.append(x)
		Utils.write_db(connection=db_con,url=url, cache_days=cache_days, folder=folder,cache_val=movies_pre_processed)
		return movies_pre_processed


def load_vod_to_sql():
	import sqlite3
	import time
	from tools import clean_title
	movies = get_vod_allmovies()
	TV = get_vod_alltv()

	db_path = Utils.VOD_CACHE_PATH
	conn = sqlite3.connect(db_path)
	cur = conn.cursor()

	cur.execute("""
		CREATE TABLE IF NOT EXISTS meta (
			key TEXT PRIMARY KEY,
			value TEXT
		)
	""")
	conn.commit()

	cur.execute("SELECT value FROM meta WHERE key='last_updated'")
	row = cur.fetchone()

	if row:
		last_updated = float(row[0])
		age_seconds = time.time() - last_updated

		# if less than 1 hour old skip rebuild
		if age_seconds < 3600:
			Utils.tools_log(f"VOD DB fresh ({age_seconds:.0f}s old), skipping rebuild")
			return conn

	cur.execute("""
		CREATE TABLE IF NOT EXISTS vod (
			title_tmdb TEXT UNIQUE,
			title TEXT,
			type TEXT,
			tmdb TEXT,
			clean_title TEXT,
			year TEXT,
			name TEXT
		)
	""")
	conn.commit()


	cur.execute("""
	INSERT INTO meta (key, value)
	VALUES ('last_updated', ?)
	ON CONFLICT(key) DO UPDATE SET value=excluded.value
	""", (str(time.time()),))
	conn.commit()

	vod_items = []
	for i in movies:
		re_match = re.search(r"^(.*)\((\d{4})\)\s*$", i['title'])
		if re_match:
			name = clean_title(str(re_match.group(1).strip()).lower(), broken=2)
			try: year = re_match.group(2)
			except: year = ''
		else:
			name = clean_title(str(i['title']).lower(), broken=2)
			year = ''
		curr_item = {'title_tmdb': str(i['title']) + '_' + str(i['tmdb']), 'title': i['title'],'type': i['type'],'tmdb': str(i['tmdb']),'clean_title': clean_title(str(i['title']).lower(), broken=2), 'year': year, 'name': name}
		vod_items.append(curr_item)
	for i in TV:
		re_match = re.search(r"^(.*)\((\d{4})\)\s*$", i['title'])
		if re_match:
			name = clean_title(str(re_match.group(1).strip()).lower(), broken=2)
			try: year = re_match.group(2)
			except: year = ''
		else:
			name = clean_title(str(i['title']).lower(), broken=2)
			year = ''
		curr_item = {'title_tmdb': str(i['title']) + '_' + str(i['tmdb']), 'title': i['title'],'type': i['type'],'tmdb': str(i['tmdb']),'clean_title': clean_title(str(i['title']).lower(), broken=2), 'year': year, 'name': name}
		vod_items.append(curr_item)

	records = [(x['title_tmdb'], x['title'], x['type'], x['tmdb'], x['clean_title'], x['year'], x['name']) for x in vod_items]

	cur.executemany("INSERT or IGNORE INTO vod (title_tmdb, title, type, tmdb,clean_title, year, name) VALUES (?, ?, ?, ?, ?, ?, ?)", records)

	conn.commit()
	#Utils.tools_log(len(records))
	return conn

def filter_vod(movie_tv_items):
	#from resources.lib.TheMovieDB import load_vod_to_sql
	try: 
		FILTERED = movie_tv_items[0].get('FILTERED',False)
	except IndexError: 
		Utils.tools_log('BLANK__LIST??')
		return movie_tv_items
	if FILTERED == True:
		Utils.tools_log('filter_vod__FILTERED==TRUE')
		return movie_tv_items
	Utils.tools_log('filter_vod')

	import sqlite3
	from tools import clean_title
	load_vod_to_sql()

	results = []
	db_path = Utils.VOD_CACHE_PATH
	conn = sqlite3.connect(db_path)
	cur = conn.cursor()

	for i in movie_tv_items:
		#Utils.tools_log(i)
		i['FILTERED'] = True
		tmdb_id_trakt = i.get('ids',{}).get('tmdb',None)
		if tmdb_id_trakt:
			if 'media.trakt.tv/images/movie' in str(i):
				i['media_type'] = 'movie'
			elif 'media.trakt.tv/images/show' in str(i) or 'media.trakt.tv/images/episode' in str(i) or 'media.trakt.tv/images/season' in str(i):
				i['media_type'] = 'tv'
				i['TVShowTitle'] = i['title']
			i['id'] = tmdb_id_trakt
			i['tmdb_id'] = tmdb_id_trakt
		try: 
			media_type = i['media_type']
			try: tmdb_id = i['id']
			except: tmdb_id = i['tmdb_id']
			#imdb_id = get_imdb_id_from_movie_id(movie_id=tmdb_id)
			#Utils.tools_log(imdb_id)
			title = i['title']
			try: year = i['year']
			except: 
				try: year = i['release_date'][:4]
				except: year = i['first_air_date'][:4]
		except: 
#			Utils.tools_log(i,'EXCEPT__filter_vod')
			if i.get('show',False) == False:
				media_type = 'movie'
				try: tmdb_id = i['movie']['ids']['tmdb']
				except: tmdb_id = i['ids']['tmdb']
				year = i['movie']['year']
				title = i['movie']['title']
			else:
				media_type = 'tv'
				try: tmdb_id = i['show']['ids']['tmdb']
				except: tmdb_id = i['ids']['tmdb']
				year = i['show']['year']
				title = i['show']['title']
		if media_type == 'episode':
			tmdb_id = i['tmdb_id']
			title = i['TVShowTitle']
		cleaned_title = clean_title(str(title).lower(), broken=2)
		if media_type == 'movie':
			cur.execute("SELECT * FROM vod WHERE type = 'movie' and (tmdb = ? or (name = ? and year = ?))", (tmdb_id,cleaned_title,year,))
		else:
			cur.execute("SELECT * FROM vod WHERE type <> 'movie' and (tmdb = ? or clean_title = ?)", (tmdb_id,cleaned_title,))
		result1 = cur.fetchall()
		if len(result1) >= 1:
			#Utils.tools_log(result1)
			results.append(i)
	return results



def get_imdb_watchlist_items(movies=None, limit=0, cache_days=14, folder='IMDB', imdb_url=None):
	import time, hashlib, xbmcvfs, os
	import re, json, requests, html

	#cache_days = 0.0001
	#Utils.tools_log(i)
	if imdb_url:
		url = imdb_url +'/get_imdb_watchlist_items'
	else:
		url = 'imdb_'
		for i in movies:
			url = url + str(i) +'/get_imdb_watchlist_items'

	now = time.time()
	url = url.encode('utf-8')
	hashed_url = hashlib.md5(url).hexdigest()
	cache_path = xbmcvfs.translatePath(os.path.join(Utils.ADDON_DATA_PATH, folder)) if folder else xbmcvfs.translatePath(os.path.join(Utils.ADDON_DATA_PATH))
	cache_seconds = int(cache_days * 86400.0)
	path = os.path.join(cache_path, '%s.txt' % hashed_url)

	try: 
		db_result, expired_db_result = Utils.query_db(connection=Utils.db_con,url=url, cache_days=cache_days, folder=folder, headers=None)
	except:
		db_result, expired_db_result = None, None
	if db_result and len(db_result) > 0:
		return db_result
	else:

		listitems = None
		x = 0
		if not movies:
			return None
		for y in movies:
			imdb_id = y
			response = get_tmdb_data('find/%s?language=%s&external_source=imdb_id&' % (imdb_id, xbmcaddon.Addon().getSetting('LanguageID')), 13)
			try:
				response['movie_results'][0]['media_type'] = 'movie'
				if listitems == None:
					listitems = handle_tmdb_multi_search(response['movie_results'])
				else:
					listitems += handle_tmdb_multi_search(response['movie_results'])
			except:
				try:
					response['tv_results'][0]['media_type'] = 'tv'
					if listitems == None:
						listitems = handle_tmdb_multi_search(response['tv_results'])
					else:
						listitems += handle_tmdb_multi_search(response['tv_results'])
				except:
					continue
			if x + 1 == int(limit) and limit != 0:
				break
			x = x + 1
		listitems = filter_vod(listitems)

		if not listitems or len(listitems) == 0:
			if expired_db_result == None:
				return []
			if len(expired_db_result) > 0:
				write_db(connection=Utils.db_con,url=url, cache_days=0.25, folder=folder,cache_val=expired_db_result)
				return expired_db_result
			return []
		else:
			Utils.write_db(connection=Utils.db_con,url=url, cache_days=cache_days, folder=folder,cache_val=listitems)
		return listitems