This script can automaticly download all available artwork for your movies/tvshows in your library.
!!Each Movies and TV Show must have it's own subfolder!!

----------------------------------------------------------------------------------------------
To run the script in bulk mode simply click on it in the 'Addons' or 'Programs' menu in XBMC.
You can change the settings if you wish in the addon settings page.

[Titna Skin]
To run the script on a specific movie/show, open the video information dialog,
Then press on the "Artwork Downloader" button.

This script has some different run modes. Please check the XBMC wiki page:

http://wiki.xbmc.org/index.php?title=Add-on:Artwork_Downloader

----------------------------------------------------------------------------------------------

For better usage of the addon please create, activate and set all of those API keys:
* Fanart.tv (fanart.tv) - Project Key
* TMDb (www.themoviedb.org)
* TheTVDB (thetvdb.com)

----------------------------------------------------------------------------------------------

Thanks to these sites:
* kodi.tv
* fanart.tv
* thetvdb.com
* themoviedb.org

Add-on authors:
paddycarey, Martijn Kaijser, putneyj, burekas

Thanks to:
Team Kodi and the authors of the other addons on which this was based.